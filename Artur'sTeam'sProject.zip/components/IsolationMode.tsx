import * as React from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import Group from "../assets/group.svg";
import Group1 from "../assets/group1.svg";
import Vector from "../assets/vector.svg";
import Vector1 from "../assets/vector1.svg";
import Vector2 from "../assets/vector2.svg";
import Vector3 from "../assets/vector3.svg";
import Vector4 from "../assets/vector4.svg";
import Vector5 from "../assets/vector5.svg";
import Vector6 from "../assets/vector6.svg";
import Vector7 from "../assets/vector7.svg";
import Vector8 from "../assets/vector8.svg";
import Vector9 from "../assets/vector9.svg";
import Vector10 from "../assets/vector10.svg";
import Vector11 from "../assets/vector11.svg";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const IsolationMode = () => {
  return (
    <View style={[styles.isolationMode, styles.textTransform]}>
      <Group
        style={[styles.groupIcon, styles.groupIconLayout]}
        width={97}
        height={98}
      />
      <Group1
        style={[styles.groupIcon1, styles.groupIconLayout]}
        width={64}
        height={96}
      />
      <View style={[styles.group, styles.vectorIconPosition1]}>
        <Vector
          style={[styles.vectorIcon, styles.vectorIconPosition1]}
          width={95}
          height={79}
        />
        <Vector1
          style={[styles.vectorIcon1, styles.vectorIconPosition1]}
          width={95}
          height={77}
        />
        <Vector2
          style={[styles.vectorIcon2, styles.groupIconLayout]}
          width={94}
          height={77}
        />
        <Vector3
          style={[styles.vectorIcon3, styles.groupIconLayout]}
          width={15}
          height={16}
        />
        <Vector4
          style={[styles.vectorIcon4, styles.groupIconLayout]}
          width={16}
          height={17}
        />
        <Vector5
          style={[styles.vectorIcon5, styles.groupIconLayout]}
          width={16}
          height={16}
        />
        <Vector6
          style={[styles.vectorIcon6, styles.vectorIconPosition]}
          width={10}
          height={12}
        />
        <Vector7
          style={[styles.vectorIcon7, styles.groupIconLayout]}
          width={11}
          height={12}
        />
        <Vector8
          style={[styles.vectorIcon8, styles.vectorIconPosition]}
          width={11}
          height={12}
        />
        <Vector9
          style={[styles.vectorIcon9, styles.groupIconLayout]}
          width={6}
          height={9}
        />
        <Vector10
          style={[styles.vectorIcon10, styles.vectorIconLayout]}
          width={6}
          height={10}
        />
        <Vector11
          style={[styles.vectorIcon11, styles.vectorIconLayout]}
          width={6}
          height={10}
        />
        <Text style={[styles.text, styles.textTransform]}>{`Դեռ չե՞ս
գրանցվել`}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  textTransform: {
    transform: [
      {
        rotate: "180deg",
      },
    ],
    position: "absolute",
  },
  groupIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  vectorIconPosition1: {
    top: "0%",
    position: "absolute",
  },
  vectorIconPosition: {
    bottom: "2.83%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  vectorIconLayout: {
    top: "90.18%",
    width: "6.25%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  groupIcon: {
    top: "0.88%",
    left: "0.78%",
    bottom: "1.24%",
    right: "2.03%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
  },
  groupIcon1: {
    top: "2.92%",
    left: "33.49%",
    bottom: "1.24%",
    right: "2.03%",
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
  },
  vectorIcon: {
    right: "100%",
    bottom: "21.15%",
    left: "-95.16%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  vectorIcon1: {
    right: "100.08%",
    bottom: "23.1%",
    left: "-95.08%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  vectorIcon2: {
    top: "0.8%",
    right: "102.03%",
    bottom: "22.21%",
    left: "-96.49%",
    position: "absolute",
    maxHeight: "100%",
    maxWidth: "100%",
  },
  vectorIcon3: {
    top: "76.46%",
    right: "163.39%",
    bottom: "7.96%",
    left: "-78.84%",
    position: "absolute",
    maxHeight: "100%",
    maxWidth: "100%",
  },
  vectorIcon4: {
    top: "76.64%",
    right: "164.56%",
    bottom: "6.55%",
    left: "-80.09%",
    position: "absolute",
    maxHeight: "100%",
    maxWidth: "100%",
  },
  vectorIcon5: {
    top: "76.19%",
    right: "162.53%",
    bottom: "7.52%",
    left: "-78.45%",
    position: "absolute",
    maxHeight: "100%",
    maxWidth: "100%",
  },
  vectorIcon6: {
    top: "85.31%",
    right: "179.94%",
    left: "-90.09%",
  },
  vectorIcon7: {
    top: "85.4%",
    right: "179.78%",
    bottom: "2.3%",
    left: "-91.1%",
    position: "absolute",
    maxHeight: "100%",
    maxWidth: "100%",
  },
  vectorIcon8: {
    top: "84.96%",
    right: "181.97%",
    left: "-92.51%",
  },
  vectorIcon9: {
    top: "91.06%",
    right: "192.9%",
    bottom: "0.35%",
    left: "-98.75%",
    position: "absolute",
    maxHeight: "100%",
    maxWidth: "100%",
  },
  vectorIcon10: {
    right: "192.12%",
    left: "-98.36%",
    bottom: "0%",
  },
  vectorIcon11: {
    right: "193.75%",
    bottom: "0.27%",
    left: "-100%",
  },
  text: {
    top: "21.42%",
    left: "82.59%",
    fontSize: FontSize.size_base_7,
    fontWeight: "600",
    fontFamily: FontFamily.montserratArm,
    color: Color.color1,
    textAlign: "center",
  },
  group: {
    height: "100%",
    width: "100%",
    right: "0%",
    left: "0%",
    bottom: "0%",
  },
  isolationMode: {
    top: 12,
    left: 338,
    width: 128,
    height: 113,
    overflow: "hidden",
    transform: [
      {
        rotate: "180deg",
      },
    ],
  },
});

export default IsolationMode;
