import * as React from "react";
import { Text, StyleSheet, Image, View } from "react-native";
import Ellipse3 from "../assets/ellipse-3.svg";
import PrimaryButton from "./PrimaryButton";
import { Color, FontFamily, FontSize } from "../GlobalStyles";

const GroupComponent8 = () => {
  return (
    <View style={styles.parent}>
      <Text style={styles.text}>Որոշել եք ջնջե՞լ Ձեր հաշիվը</Text>
      <Ellipse3
        style={[styles.groupChild, styles.groupLayout]}
        width={20}
        height={20}
      />
      <Ellipse3
        style={[styles.groupItem, styles.groupLayout]}
        width={20}
        height={20}
      />
      <Ellipse3
        style={[styles.groupInner, styles.groupLayout]}
        width={20}
        height={20}
      />
      <Text style={[styles.text1, styles.textTypo]}>
        Գնումներ չեմ կատարելու
      </Text>
      <Text style={[styles.text2, styles.textTypo]}>
        Սպասարկումը չի գոհացրել
      </Text>
      <Text style={[styles.text3, styles.textTypo]}>Այլ</Text>
      <PrimaryButton
        color="Cyan"
        size="default"
        state="Default"
        primaryButtonTop={300}
        button="Ջնջել"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  groupLayout: {
    height: 20,
    width: 20,
    left: 0,
    position: "absolute",
  },
  textTypo: {
    color: Color.colorBlack,
    fontWeight: "300",
    left: 32,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  text: {
    top: 0,
    fontWeight: "500",
    color: Color.textColor,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
    fontSize: FontSize.size_sm,
    left: 0,
    position: "absolute",
  },
  groupChild: {
    top: 43,
  },
  groupItem: {
    top: 86,
  },
  groupInner: {
    top: 131,
  },
  text1: {
    top: 40,
  },
  text2: {
    top: 83,
  },
  text3: {
    top: 128,
  },
  parent: {
    top: 151,
    left: 30,
    width: 333,
    height: 350,
    position: "absolute",
  },
});

export default GroupComponent8;
