import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import {
  Color,
  FontFamily,
  FontSize,
  Border,
  Padding,
  Gap,
} from "../GlobalStyles";

export type InputFieldsType = {
  placeholder1?: string;
  showPlaceholder?: boolean;
  placeholder2?: string;

  /** Variant props */
  placeholder?: boolean;
  state?: string;

  /** Style props */
  inputFieldsTop?: number | string;
  inputFieldsLeft?: number | string;
  inputFieldsMarginLeft?: number | string;
  inputFieldsWidth?: number | string;
  inputFieldsElevation?: number;
  placeholderFontWeight?: string;
};

const getStyleValue = (key: string, value: string | number | undefined) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const InputFields = ({
  placeholder = true,
  state = "Default",
  inputFieldsTop,
  inputFieldsLeft,
  inputFieldsMarginLeft,
  inputFieldsWidth,
  inputFieldsElevation,
  placeholder1,
  showPlaceholder,
  placeholder2,
  placeholderFontWeight,
}: InputFieldsType) => {
  const inputFieldsStyle = useMemo(() => {
    return {
      ...getStyleValue("top", inputFieldsTop),
      ...getStyleValue("left", inputFieldsLeft),
      ...getStyleValue("marginLeft", inputFieldsMarginLeft),
      ...getStyleValue("width", inputFieldsWidth),
      ...getStyleValue("elevation", inputFieldsElevation),
    };
  }, [
    inputFieldsTop,
    inputFieldsLeft,
    inputFieldsMarginLeft,
    inputFieldsWidth,
    inputFieldsElevation,
  ]);

  const placeholderStyle = useMemo(() => {
    return {
      ...getStyleValue("fontWeight", placeholderFontWeight),
    };
  }, [placeholderFontWeight]);

  return (
    <View style={[styles.inputFields, inputFieldsStyle]}>
      {showPlaceholder && (
        <Text style={[styles.placeholder, styles.placeholderTypo]}>
          {placeholder1}
        </Text>
      )}
      <View style={styles.placeholderWrapper}>
        <Text style={[styles.placeholderTypo, placeholderStyle]}>
          {placeholder2}
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  placeholderTypo: {
    textAlign: "left",
    color: Color.secondaryText,
    fontFamily: FontFamily.montserratArm,
    lineHeight: 20,
    fontSize: FontSize.size_sm,
  },
  placeholder: {
    fontWeight: "500",
    alignSelf: "stretch",
  },
  placeholderWrapper: {
    borderRadius: Border.br_5xs,
    backgroundColor: Color.themeBackground,
    borderStyle: "solid",
    borderColor: Color.strokeColor,
    borderWidth: 1,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Padding.p_base,
    paddingVertical: Padding.p_mini,
    alignSelf: "stretch",
  },
  inputFields: {
    position: "absolute",
    top: 179,
    left: 30,
    width: 333,
    gap: Gap.gap_xs,
  },
});

export default InputFields;
