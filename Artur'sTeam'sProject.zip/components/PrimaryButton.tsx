import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { Color, FontSize, FontFamily, Border, Padding } from "../GlobalStyles";

export type PrimaryButtonType = {
  button?: string;

  /** Variant props */
  color?: "Cyan" | "Orange";
  size?: string;
  state?: string;

  /** Style props */
  primaryButtonTop?: number | string;
  primaryButtonLeft?: number | string;

  /** Action props */
  onPrimaryButtonPress?: () => void;
};

const getStyleValue = (key: string, value: string | number | undefined) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const PrimaryButton = ({
  color = "Cyan",
  size = "default",
  state = "Default",
  primaryButtonTop,
  primaryButtonLeft,
  onPrimaryButtonPress,
  button,
}: PrimaryButtonType) => {
  const primaryButtonStyle = useMemo(() => {
    return {
      ...getStyleValue("top", primaryButtonTop),
      ...getStyleValue("left", primaryButtonLeft),
    };
  }, [primaryButtonTop, primaryButtonLeft]);

  const getPrimaryButtonContainerStyle = () => {
    if (color === "Orange" && size === "default" && state === "Default")
      return styles.primaryButtonContainerVar;
  };
  const getButtonTextStyle = () => {
    if (color === "Orange" && size === "default" && state === "Default")
      return styles.buttonTextVar;
  };

  return (
    <View
      style={[
        styles.root,
        getPrimaryButtonContainerStyle(),
        primaryButtonStyle,
      ]}
      onPress={onPrimaryButtonPress}
    >
      <Text style={[styles.button, getButtonTextStyle()]}>{button}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  primaryButtonContainerVar: {
    backgroundColor: Color.color1,
  },
  buttonTextVar: {
    alignSelf: null,
    flex: null,
    textAlign: "left",
  },
  button: {
    alignSelf: "stretch",
    flex: 1,
    fontSize: FontSize.size_lg,
    fontWeight: "500",
    fontFamily: FontFamily.montserratArm,
    color: Color.textColor,
    textAlign: "center",
  },
  root: {
    position: "absolute",
    top: 386,
    left: 0,
    borderRadius: Border.br_5xs,
    backgroundColor: Color.color2,
    width: 333,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Padding.p_31xl,
    paddingVertical: Padding.p_sm,
  },
});

export default PrimaryButton;
