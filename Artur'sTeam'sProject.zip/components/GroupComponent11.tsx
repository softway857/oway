import * as React from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import Lucidefacebook from "../assets/lucidefacebook.svg";
import Lucideinstagram from "../assets/lucideinstagram.svg";
import Lucideglobe from "../assets/lucideglobe.svg";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const GroupComponent11 = () => {
  return (
    <View style={[styles.rectangleParent, styles.groupChildLayout]}>
      <View style={[styles.groupChild, styles.groupChildLayout]} />
      <Lucidefacebook
        style={[styles.lucidefacebookIcon, styles.iconLayout]}
        width={24}
        height={24}
      />
      <Lucideinstagram
        style={[styles.lucideinstagramIcon, styles.iconLayout]}
        width={24}
        height={24}
      />
      <Lucideglobe
        style={[styles.lucideglobeIcon, styles.iconLayout]}
        width={24}
        height={24}
      />
      <View style={styles.infoonewayamParent}>
        <Text style={[styles.infoonewayam, styles.textTypo]}>
          info@oneway.am
        </Text>
        <Text style={[styles.wwwonewayam, styles.textTypo]}>www.oneway.am</Text>
        <Text style={[styles.text, styles.textTypo]}>Հետևեք մեզ</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  groupChildLayout: {
    height: 149,
    width: 333,
    position: "absolute",
  },
  iconLayout: {
    overflow: "hidden",
    height: 24,
    width: 24,
    position: "absolute",
  },
  textTypo: {
    textAlign: "left",
    color: Color.textColor,
    fontFamily: FontFamily.montserratArm,
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  groupChild: {
    top: 0,
    left: 0,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    borderRadius: Border.br_6xs,
    backgroundColor: Color.themeBackground,
  },
  lucidefacebookIcon: {
    left: 128,
    top: 107,
  },
  lucideinstagramIcon: {
    left: 167,
    top: 107,
  },
  lucideglobeIcon: {
    top: 64,
    left: 19,
  },
  infoonewayam: {
    top: "0%",
    fontWeight: "500",
    left: "18.24%",
    color: Color.textColor,
    fontFamily: FontFamily.montserratArm,
    fontSize: FontSize.size_sm,
  },
  wwwonewayam: {
    top: "42.31%",
    fontWeight: "500",
    left: "18.24%",
    color: Color.textColor,
    fontFamily: FontFamily.montserratArm,
    fontSize: FontSize.size_sm,
  },
  text: {
    top: "83.65%",
    left: "0%",
    color: Color.textColor,
    fontFamily: FontFamily.montserratArm,
    fontSize: FontSize.size_sm,
  },
  infoonewayamParent: {
    height: "69.8%",
    width: "44.44%",
    top: "15.44%",
    right: "49.25%",
    bottom: "14.77%",
    left: "6.31%",
    position: "absolute",
  },
  rectangleParent: {
    top: 404,
    left: 30,
  },
});

export default GroupComponent11;
