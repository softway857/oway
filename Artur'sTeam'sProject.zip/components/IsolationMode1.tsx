import * as React from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import Group2 from "../assets/group2.svg";
import Vector12 from "../assets/vector12.svg";
import Vector13 from "../assets/vector13.svg";
import Vector14 from "../assets/vector14.svg";
import Vector15 from "../assets/vector15.svg";
import Vector16 from "../assets/vector16.svg";
import Vector17 from "../assets/vector17.svg";
import Vector18 from "../assets/vector18.svg";
import Vector19 from "../assets/vector19.svg";
import Vector20 from "../assets/vector20.svg";
import Vector21 from "../assets/vector21.svg";
import Vector22 from "../assets/vector22.svg";
import Vector23 from "../assets/vector23.svg";
import Vector24 from "../assets/vector24.svg";
import Vector25 from "../assets/vector25.svg";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const IsolationMode1 = () => {
  return (
    <View style={styles.isolationMode}>
      <Group2
        style={[styles.groupIcon, styles.iconLayout]}
        width={98}
        height={98}
      />
      <View style={styles.group}>
        <Vector12
          style={[styles.vectorIcon, styles.iconLayout]}
          width={1}
          height={3}
        />
        <Vector13
          style={[styles.vectorIcon1, styles.vectorIconPosition2]}
          width={8}
          height={12}
        />
        <Vector14
          style={[styles.vectorIcon2, styles.iconLayout]}
          width={9}
          height={12}
        />
        <Vector15
          style={[styles.vectorIcon3, styles.vectorIconPosition1]}
          width={80}
          height={80}
        />
        <Vector16
          style={[styles.vectorIcon4, styles.vectorIconPosition]}
          width={16}
          height={12}
        />
        <Text style={styles.text}>Բարի գալուստ</Text>
      </View>
      <Vector17
        style={[styles.vectorIcon5, styles.vectorIconPosition1]}
        width={99}
        height={84}
      />
      <Vector18
        style={[styles.vectorIcon6, styles.vectorIconPosition]}
        width={97}
        height={79}
      />
      <Vector19
        style={[styles.vectorIcon7, styles.iconLayout]}
        width={95}
        height={78}
      />
      <Vector20
        style={[styles.vectorIcon8, styles.vectorIconLayout]}
        width={10}
        height={11}
      />
      <Vector21
        style={[styles.vectorIcon9, styles.iconLayout]}
        width={10}
        height={12}
      />
      <Vector22
        style={[styles.vectorIcon10, styles.iconLayout]}
        width={11}
        height={14}
      />
      <Vector23
        style={[styles.vectorIcon11, styles.iconLayout]}
        width={8}
        height={12}
      />
      <Vector24
        style={[styles.vectorIcon12, styles.vectorIconPosition2]}
        width={10}
        height={11}
      />
      <Vector25
        style={[styles.vectorIcon13, styles.vectorIconLayout]}
        width={10}
        height={11}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  vectorIconPosition2: {
    bottom: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  vectorIconPosition1: {
    right: "0%",
    top: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  vectorIconPosition: {
    left: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  vectorIconLayout: {
    width: "9.84%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  groupIcon: {
    top: "0.86%",
    bottom: "1.43%",
    left: "1.71%",
    right: "0.67%",
  },
  vectorIcon: {
    top: "94.71%",
    right: "93.35%",
    bottom: "2.71%",
    left: "6.03%",
  },
  vectorIcon1: {
    top: "88.44%",
    right: "85.13%",
    left: "7.28%",
  },
  vectorIcon2: {
    top: "73.31%",
    right: "75.27%",
    bottom: "14.51%",
    left: "15.96%",
  },
  vectorIcon3: {
    bottom: "20.42%",
    left: "20.19%",
  },
  vectorIcon4: {
    top: "38.99%",
    right: "84.19%",
    bottom: "49.32%",
  },
  text: {
    top: "15.87%",
    left: "6.18%",
    fontSize: FontSize.size_smi_9,
    fontWeight: "600",
    fontFamily: FontFamily.montserratArm,
    color: Color.colorDarkcyan,
    textAlign: "center",
    position: "absolute",
  },
  group: {
    height: "77.43%",
    width: "95.23%",
    top: "21.24%",
    bottom: "1.33%",
    left: "4.1%",
    right: "0.67%",
    position: "absolute",
  },
  vectorIcon5: {
    bottom: "16.29%",
    left: "0.97%",
  },
  vectorIcon6: {
    top: "1.9%",
    right: "3.13%",
    bottom: "18.76%",
  },
  vectorIcon7: {
    top: "3.81%",
    right: "4.47%",
    bottom: "17.81%",
    left: "0.52%",
  },
  vectorIcon8: {
    top: "75.81%",
    right: "73.85%",
    bottom: "13.14%",
    left: "16.32%",
  },
  vectorIcon9: {
    top: "76.38%",
    right: "71.68%",
    bottom: "11.71%",
    left: "18.41%",
  },
  vectorIcon10: {
    top: "75.14%",
    right: "73.32%",
    bottom: "10.95%",
    left: "15.8%",
  },
  vectorIcon11: {
    top: "87.9%",
    right: "82.34%",
    bottom: "0.57%",
    left: "9.69%",
  },
  vectorIcon12: {
    top: "88.57%",
    right: "80.63%",
    left: "9.76%",
  },
  vectorIcon13: {
    top: "88.67%",
    right: "81.07%",
    bottom: "0.48%",
    left: "9.09%",
  },
  isolationMode: {
    top: 17,
    left: 216,
    width: 134,
    height: 105,
    overflow: "hidden",
    position: "absolute",
  },
});

export default IsolationMode1;
