import * as React from "react";
import Group15 from "../assets/group-15.svg";
import Vector26 from "../assets/vector26.svg";
import { Color, Border, FontFamily, FontSize, Gap } from "../GlobalStyles";

const Addrees = () => {
  return (
    <View style={styles.addrees}>
      <View style={[styles.addreesChild, styles.groupInnerBg]} />
      <Text style={styles.text}>Հասցեներ</Text>
      <Group15 style={styles.addreesItem} width={40} height={40} />
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.groupPosition]} />
        <View style={[styles.vectorParent, styles.groupParentPosition]}>
          <Vector26
            style={[styles.vectorIcon, styles.vectorIconPosition]}
            width={9}
            height={41}
          />
          <View style={[styles.addressLine1Parent, styles.parentPosition]}>
            <Text style={[styles.addressLine1, styles.eAyreStreetPosition]}>
              ADDRESS LINE 1
            </Text>
            <Text style={[styles.eAyreStreet, styles.eAyreStreetPosition]}>
              1622 E Ayre Street
            </Text>
          </View>
        </View>
        <View style={[styles.vectorGroup, styles.groupParentPosition]}>
          <Vector26
            style={[styles.vectorIcon1, styles.vectorIconPosition]}
            width={10}
            height={41}
          />
          <View style={[styles.addressLine2Parent, styles.parentPosition]}>
            <Text style={[styles.addressLine1, styles.eAyreStreetPosition]}>
              ADDRESS LINE 2
            </Text>
            <Text style={[styles.eAyreStreet, styles.eAyreStreetPosition]}>
              ARM399728
            </Text>
          </View>
        </View>
        <View style={[styles.vectorContainer, styles.groupParentPosition]}>
          <Vector26
            style={[styles.vectorIcon2, styles.vectorIconPosition]}
            width={11}
            height={41}
          />
          <View style={[styles.cityParent, styles.parentPosition]}>
            <Text style={[styles.addressLine1, styles.eAyreStreetPosition]}>
              CITY
            </Text>
            <Text style={[styles.eAyreStreet, styles.eAyreStreetPosition]}>
              WILMINGTON
            </Text>
          </View>
        </View>
        <View style={[styles.groupView, styles.groupParentPosition]}>
          <Vector26
            style={[styles.vectorIcon3, styles.vectorIconPosition]}
            width={14}
            height={41}
          />
          <View style={[styles.stateParent, styles.parentPosition]}>
            <Text style={[styles.addressLine1, styles.eAyreStreetPosition]}>
              STATE
            </Text>
            <Text style={[styles.eAyreStreet, styles.eAyreStreetPosition]}>
              Delaware
            </Text>
          </View>
        </View>
        <View style={[styles.vectorParent1, styles.groupParentPosition]}>
          <Vector26
            style={[styles.vectorIcon4, styles.vectorIconPosition]}
            width={15}
            height={41}
          />
          <View style={[styles.zipCodeParent, styles.parentPosition]}>
            <Text style={[styles.addressLine1, styles.eAyreStreetPosition]}>
              ZIP CODE
            </Text>
            <Text style={[styles.eAyreStreet, styles.eAyreStreetPosition]}>
              19804
            </Text>
          </View>
        </View>
        <View style={[styles.vectorParent2, styles.groupParentPosition]}>
          <Vector26
            style={[styles.vectorIcon5, styles.vectorIconPosition]}
            width={15}
            height={41}
          />
          <View style={[styles.countryParent, styles.parentPosition]}>
            <Text style={[styles.addressLine1, styles.eAyreStreetPosition]}>
              COUNTRY
            </Text>
            <Text style={[styles.eAyreStreet, styles.eAyreStreetPosition]}>
              USA
            </Text>
          </View>
        </View>
        <View style={[styles.vectorParent3, styles.groupParentPosition]}>
          <Vector26
            style={[styles.vectorIcon6, styles.vectorIconPosition]}
            width={10}
            height={41}
          />
          <View style={[styles.phoneParent, styles.parentPosition]}>
            <Text style={[styles.addressLine1, styles.eAyreStreetPosition]}>
              PHONE
            </Text>
            <Text style={[styles.eAyreStreet, styles.eAyreStreetPosition]}>
              +1 3026608398
            </Text>
          </View>
        </View>
      </View>
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
      <View style={[styles.rectangleGroup, styles.groupLayout]}>
        <View style={[styles.groupItem, styles.groupLayout]} />
        <View style={styles.flagUsasvgParent}>
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg4.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/russiasvg.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg10.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg11.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg3.png")}
          />
        </View>
        <View style={[styles.groupInner, styles.groupInnerBg]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  groupInnerBg: {
    backgroundColor: Color.color2,
    position: "absolute",
  },
  groupChildLayout: {
    height: 517,
    width: 333,
    position: "absolute",
  },
  groupPosition: {
    backgroundColor: Color.themeBackground,
    borderRadius: Border.br_6xs,
    shadowOpacity: 1,
    left: 0,
    top: 0,
  },
  groupParentPosition: {
    left: "4.5%",
    height: "9.86%",
    position: "absolute",
  },
  vectorIconPosition: {
    maxHeight: "100%",
    maxWidth: "100%",
    left: "0%",
    bottom: "29.41%",
    top: "29.41%",
    height: "41.18%",
    position: "absolute",
    overflow: "hidden",
  },
  parentPosition: {
    height: 51,
    left: 44,
    top: 0,
    position: "absolute",
  },
  eAyreStreetPosition: {
    lineHeight: 23,
    left: 0,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    position: "absolute",
  },
  groupLayout: {
    height: 70,
    width: 333,
    position: "absolute",
  },
  addreesChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    width: 426,
    height: 158,
  },
  text: {
    top: 32,
    left: 85,
    fontSize: FontSize.size_lg,
    lineHeight: 25,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    color: Color.textColor,
    fontWeight: "500",
    position: "absolute",
  },
  addreesItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  groupChild: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 4,
    elevation: 4,
    height: 517,
    width: 333,
    position: "absolute",
  },
  vectorIcon: {
    right: "91.21%",
  },
  addressLine1: {
    fontSize: FontSize.size_sm,
    color: Color.colorDimgray_100,
    top: 0,
    lineHeight: 23,
  },
  eAyreStreet: {
    top: 28,
    fontSize: FontSize.size_base,
    lineHeight: 23,
    color: Color.textColor,
    fontWeight: "500",
  },
  addressLine1Parent: {
    width: 146,
  },
  vectorParent: {
    width: "57.06%",
    top: "3.87%",
    right: "38.44%",
    bottom: "86.27%",
  },
  vectorIcon1: {
    right: "89.63%",
  },
  addressLine2Parent: {
    width: 117,
  },
  vectorGroup: {
    width: "48.35%",
    top: "17.6%",
    right: "47.15%",
    bottom: "72.53%",
  },
  vectorIcon2: {
    right: "89.16%",
  },
  cityParent: {
    width: 110,
  },
  vectorContainer: {
    width: "46.25%",
    top: "31.33%",
    right: "49.25%",
    bottom: "58.8%",
  },
  vectorIcon3: {
    right: "86.08%",
  },
  stateParent: {
    width: 76,
  },
  groupView: {
    width: "36.04%",
    top: "45.07%",
    right: "59.46%",
    bottom: "45.07%",
  },
  vectorIcon4: {
    right: "85.22%",
  },
  zipCodeParent: {
    width: 69,
  },
  vectorParent1: {
    width: "33.93%",
    top: "58.8%",
    right: "61.56%",
    bottom: "31.33%",
  },
  vectorIcon5: {
    right: "85.35%",
  },
  countryParent: {
    width: 70,
  },
  vectorParent2: {
    width: "34.23%",
    top: "72.53%",
    right: "61.26%",
    bottom: "17.6%",
  },
  vectorIcon6: {
    right: "89.88%",
  },
  phoneParent: {
    width: 121,
  },
  vectorParent3: {
    width: "49.55%",
    top: "86.27%",
    right: "45.95%",
    bottom: "3.87%",
  },
  rectangleParent: {
    top: 269,
    left: 30,
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  groupItem: {
    shadowColor: "rgba(0, 0, 0, 0.05)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 2,
    elevation: 2,
    backgroundColor: Color.themeBackground,
    borderRadius: Border.br_6xs,
    shadowOpacity: 1,
    left: 0,
    top: 0,
  },
  flagUsasvgIcon: {
    width: 45,
    height: 27,
    overflow: "hidden",
  },
  flagUsasvgParent: {
    top: 22,
    left: 17,
    flexDirection: "row",
    alignItems: "center",
    gap: Gap.gap_xl,
    position: "absolute",
  },
  groupInner: {
    top: 56,
    left: 13,
    width: 2,
    height: 54,
    transform: [
      {
        rotate: "-90deg",
      },
    ],
  },
  rectangleGroup: {
    top: 88,
    left: 30,
  },
  addrees: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default Addrees;
