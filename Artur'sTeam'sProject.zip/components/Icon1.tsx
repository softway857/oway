import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Padding } from "../GlobalStyles";

export type Icon1Type = {
  /** Variant props */
  size?: 12;
};

const Icon1 = ({ size = 10 }: Icon1Type) => {
  return (
    <View style={[styles.resizeHandle, styles.resizeHandleFlexBox]}>
      <View style={styles.glyphArea}>
        <Text style={[styles.emoticonOutline, styles.resizeHandleFlexBox]}>
          󰑝
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  resizeHandleFlexBox: {
    alignItems: "center",
    position: "absolute",
  },
  emoticonOutline: {
    height: "116.67%",
    width: "116.67%",
    top: "-7.5%",
    left: "-8.33%",
    fontSize: FontSize.size_mini_4,
    fontFamily: FontFamily.compassIcons,
    color: Color.strokeColor,
    textAlign: "center",
    display: "flex",
    justifyContent: "center",
  },
  glyphArea: {
    width: 12,
    height: 12,
  },
  resizeHandle: {
    right: 1,
    bottom: 1,
    flexDirection: "row",
    padding: Padding.p_11xs,
    zIndex: 1,
  },
});

export default Icon1;
