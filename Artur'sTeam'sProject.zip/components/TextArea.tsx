import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import Icon1 from "./Icon1";
import {
  FontSize,
  FontFamily,
  Color,
  Border,
  Padding,
  Gap,
} from "../GlobalStyles";

export type TextAreaType = {
  /** Variant props */
  placeholder?: boolean;
  state?: string;
};

const TextArea = ({ placeholder = true, state = "default" }: TextAreaType) => {
  return (
    <View style={styles.textArea}>
      <Text style={styles.placeholder}>Խնդրում եմ նշեք պատճառը</Text>
      <Icon1 size={12} />
    </View>
  );
};

const styles = StyleSheet.create({
  placeholder: {
    alignSelf: "stretch",
    flex: 1,
    fontSize: FontSize.size_xs,
    lineHeight: 20,
    fontFamily: FontFamily.montserratArm,
    color: Color.secondaryText,
    textAlign: "left",
    zIndex: 0,
  },
  textArea: {
    position: "absolute",
    top: 36,
    left: 0,
    borderRadius: Border.br_5xs,
    backgroundColor: Color.themeBackground,
    borderStyle: "solid",
    borderColor: Color.strokeColor,
    borderWidth: 1,
    width: 333,
    height: 96,
    paddingHorizontal: Padding.p_base,
    paddingVertical: Padding.p_6xs,
    gap: Gap.gap_lg,
  },
});

export default TextArea;
