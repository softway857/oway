import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

export type BadgeCountType = {
  showBadgeCount?: boolean;
  label?: string;

  /** Variant props */
  property1?: string;
  size?: string;

  /** Style props */
  badgeCountMarginTop?: number | string;
  badgeCountPosition?: string;
  badgeCountMarginLeft?: number | string;
  badgeCountTop?: number | string;
  badgeCountLeft?: number | string;
  badgeCountBorderRadius?: number;
  badgeCountWidth?: number | string;
  badgeCountHeight?: number | string;
};

const getStyleValue = (key: string, value: string | number | undefined) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const BadgeCount = ({
  property1 = "Default",
  size = "Large",
  showBadgeCount,
  badgeCountMarginTop,
  badgeCountPosition,
  badgeCountMarginLeft,
  badgeCountTop,
  badgeCountLeft,
  badgeCountBorderRadius,
  badgeCountWidth,
  badgeCountHeight,
  label,
}: BadgeCountType) => {
  const badgeCountStyle = useMemo(() => {
    return {
      ...getStyleValue("marginTop", badgeCountMarginTop),
      ...getStyleValue("position", badgeCountPosition),
      ...getStyleValue("marginLeft", badgeCountMarginLeft),
      ...getStyleValue("top", badgeCountTop),
      ...getStyleValue("left", badgeCountLeft),
      ...getStyleValue("borderRadius", badgeCountBorderRadius),
      ...getStyleValue("width", badgeCountWidth),
      ...getStyleValue("height", badgeCountHeight),
    };
  }, [
    badgeCountMarginTop,
    badgeCountPosition,
    badgeCountMarginLeft,
    badgeCountTop,
    badgeCountLeft,
    badgeCountBorderRadius,
    badgeCountWidth,
    badgeCountHeight,
  ]);

  return (
    showBadgeCount && (
      <View style={[styles.badgeCount, badgeCountStyle]}>
        <Text style={styles.label}>{label}</Text>
      </View>
    )
  );
};

const styles = StyleSheet.create({
  label: {
    fontSize: FontSize.size_xs,
    lineHeight: 11,
    fontWeight: "500",
    fontFamily: FontFamily.interMedium,
    color: Color.darkMedium,
    textAlign: "left",
  },
  badgeCount: {
    position: "absolute",
    marginTop: -214,
    marginLeft: 117.5,
    top: "50%",
    left: "50%",
    borderRadius: Border.br_xl,
    backgroundColor: Color.greyLight,
    width: 29,
    height: 29,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Padding.p_7xs,
    paddingVertical: Padding.p_9xs,
  },
});

export default BadgeCount;
