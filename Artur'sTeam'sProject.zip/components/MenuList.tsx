import * as React from "react";
import { Image, StyleSheet, Text, View, Pressable } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Lucideplus from "../assets/lucideplus.svg";
import { FontFamily, FontSize, Color, Border, Padding } from "../GlobalStyles";

const MenuList = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.menuList}>
      <Pressable
        style={styles.iconlylightOutlinehomeParent}
        onPress={() => navigation.navigate("MainPage")}
      >
        <Image
          style={[styles.iconlylightOutlinehome, styles.iconlylightLayout]}
          resizeMode="cover"
          source={require("../assets/iconlylightoutlinehome.png")}
        />
        <Text style={[styles.text, styles.textTypo]}>Գլխավոր</Text>
      </Pressable>
      <View style={styles.menu3}>
        <Pressable
          style={styles.container}
          onPress={() => navigation.navigate("AddOrder1")}
        >
          <Lucideplus
            style={[styles.lucideplusIcon, styles.iconlylightLayout]}
            width={100}
          />
        </Pressable>
      </View>
      <View style={styles.groupParent}>
        <View style={styles.wrapper}>
          <Text style={[styles.text1, styles.textTypo]}>Ավելին</Text>
        </View>
        <Image
          style={[styles.iconlylightOutlinecategory, styles.iconlylightLayout]}
          resizeMode="cover"
          source={require("../assets/iconlylightoutlinecategory.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  iconlylightLayout: {
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
  },
  textTypo: {
    textAlign: "center",
    fontFamily: FontFamily.montserratArm,
    fontSize: FontSize.size_xs,
    left: "0%",
    position: "absolute",
  },
  iconlylightOutlinehome: {
    width: "39.34%",
    right: "31.15%",
    left: "29.51%",
    bottom: "46.67%",
    height: "53.33%",
    overflow: "hidden",
    maxWidth: "100%",
    top: "0%",
    position: "absolute",
  },
  text: {
    color: Color.colorBlack,
    top: "66.67%",
    textAlign: "center",
    fontFamily: FontFamily.montserratArm,
    fontSize: FontSize.size_xs,
  },
  iconlylightOutlinehomeParent: {
    width: 61,
    height: 45,
  },
  lucideplusIcon: {
    alignSelf: "stretch",
    flex: 1,
  },
  container: {
    borderRadius: Border.br_81xl,
    backgroundColor: Color.color2,
    borderStyle: "solid",
    borderColor: Color.themeBackground,
    borderWidth: 4,
    width: 72,
    height: 72,
    padding: Padding.p_sm,
    flexDirection: "row",
  },
  menu3: {
    alignItems: "center",
    paddingBottom: Padding.p_lg,
    flex: 1,
  },
  text1: {
    fontWeight: "600",
    color: Color.color2,
    textAlign: "center",
    fontFamily: FontFamily.montserratArm,
    fontSize: FontSize.size_xs,
    top: "0%",
  },
  wrapper: {
    height: "33.33%",
    right: "0%",
    bottom: "0%",
    width: "100%",
    left: "0%",
    top: "66.67%",
    position: "absolute",
  },
  iconlylightOutlinecategory: {
    width: "50%",
    right: "25%",
    left: "25%",
    bottom: "46.67%",
    height: "53.33%",
    overflow: "hidden",
    maxWidth: "100%",
    top: "0%",
    position: "absolute",
  },
  groupParent: {
    width: 48,
    height: 45,
  },
  menuList: {
    bottom: 31,
    left: 1,
    backgroundColor: Color.themeBackground,
    width: 393,
    alignItems: "flex-end",
    justifyContent: "center",
    paddingHorizontal: Padding.p_28xl,
    paddingVertical: 0,
    flexDirection: "row",
    position: "absolute",
  },
});

export default MenuList;
