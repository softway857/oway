import React, { useMemo } from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import Lucideplanelanding from "../assets/lucideplanelanding.svg";
import { FontFamily, FontSize, Color } from "../GlobalStyles";

export type GroupComponent2Type = {
  /** Style props */
  groupViewTop?: number | string;
};

const getStyleValue = (key: string, value: string | number | undefined) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const GroupComponent2 = ({ groupViewTop }: GroupComponent2Type) => {
  const groupView1Style = useMemo(() => {
    return {
      ...getStyleValue("top", groupViewTop),
    };
  }, [groupViewTop]);

  return (
    <View
      style={[
        styles.lucideplaneLandingParent,
        styles.parentLayout,
        groupView1Style,
      ]}
    >
      <Lucideplanelanding
        style={styles.lucideplaneLandingIcon}
        width={24}
        height={24}
      />
      <View style={[styles.parent, styles.parentLayout]}>
        <Text style={[styles.text, styles.textTypo]}>Հայաստանում է</Text>
        <Text style={[styles.text1, styles.textTypo]}>{`07/07/2024 `}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  parentLayout: {
    height: 53,
    position: "absolute",
  },
  textTypo: {
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
    fontSize: FontSize.size_sm,
    left: 0,
    position: "absolute",
  },
  lucideplaneLandingIcon: {
    top: 15,
    overflow: "hidden",
    left: 0,
    position: "absolute",
  },
  text: {
    color: Color.colorGray_100,
    top: 0,
  },
  text1: {
    top: 28,
    fontWeight: "500",
    color: Color.textColor,
  },
  parent: {
    left: 33,
    width: 123,
    top: 0,
  },
  lucideplaneLandingParent: {
    top: 425,
    left: 22,
    width: 156,
  },
});

export default GroupComponent2;
