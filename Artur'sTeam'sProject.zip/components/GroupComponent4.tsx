import React, { useMemo } from "react";
import { StyleSheet, View, Text } from "react-native";
import { FontFamily, Border, Color, FontSize } from "../GlobalStyles";

export type GroupComponent4Type = {
  /** Style props */
  groupViewTop?: number | string;
};

const getStyleValue = (key: string, value: string | number | undefined) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const GroupComponent4 = ({ groupViewTop }: GroupComponent4Type) => {
  const groupView2Style = useMemo(() => {
    return {
      ...getStyleValue("top", groupViewTop),
    };
  }, [groupViewTop]);

  return (
    <View
      style={[styles.rectangleParent, styles.groupChildLayout, groupView2Style]}
    >
      <View style={[styles.groupChild, styles.groupChildLayout]} />
      <Text style={[styles.text, styles.textTypo]}>Պատրաստ է ստացման</Text>
      <Text style={[styles.text1, styles.textTypo]}>
        Ձեր առաքանին պատրաստ է ստացման։
      </Text>
      <Text style={[styles.text2, styles.textTypo]}>07/07/2024 15:30</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  groupChildLayout: {
    height: 80,
    width: 333,
    position: "absolute",
  },
  textTypo: {
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 22,
    position: "absolute",
  },
  groupChild: {
    top: 0,
    left: 0,
    shadowColor: "rgba(143, 143, 143, 0.25)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 3,
    elevation: 3,
    shadowOpacity: 1,
    borderRadius: Border.br_8xs,
    backgroundColor: Color.themeBackground,
  },
  text: {
    top: 14,
    fontWeight: "500",
    color: Color.colorDarkslateblue,
    fontSize: FontSize.size_xs,
    left: 12,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 22,
  },
  text1: {
    top: 38,
    color: Color.textColor,
    fontSize: FontSize.size_xs,
    left: 12,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 22,
  },
  text2: {
    top: 2,
    left: 241,
    fontSize: FontSize.size_3xs,
    color: Color.colorGray_200,
  },
  rectangleParent: {
    top: 161,
    left: 30,
  },
});

export default GroupComponent4;
