import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Color, Border, FontFamily, FontSize, Padding } from "../GlobalStyles";

const GroupComponent9 = () => {
  return (
    <View style={styles.rectangleParent}>
      <View style={[styles.groupChild, styles.groupShadowBox]} />
      <View style={[styles.groupItem, styles.groupShadowBox]} />
      <View style={styles.yt343en3334Wrapper}>
        <Text style={styles.yt343en3334}>YT343EN3334</Text>
      </View>
      <Text style={styles.tracking}>Tracking համար</Text>
      <Text style={[styles.text, styles.textTypo]}>Քաշ</Text>
      <Text style={[styles.text1, styles.textTypo]}>Գումար</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  groupShadowBox: {
    backgroundColor: Color.themeBackground,
    borderRadius: Border.br_8xs,
    shadowOpacity: 1,
    elevation: 3,
    shadowRadius: 3,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(143, 143, 143, 0.25)",
    left: 0,
    width: 333,
    position: "absolute",
  },
  textTypo: {
    left: 22,
    color: Color.colorGray_100,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  groupChild: {
    top: 0,
    height: 112,
  },
  groupItem: {
    top: 128,
    height: 100,
  },
  yt343en3334: {
    fontWeight: "600",
    color: Color.colorDarkslateblue,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
    fontSize: FontSize.size_sm,
  },
  yt343en3334Wrapper: {
    top: 68,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 0,
    paddingVertical: Padding.p_8xs,
    left: 20,
    position: "absolute",
  },
  tracking: {
    top: 43,
    color: Color.colorGray_100,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
    fontSize: FontSize.size_sm,
    left: 20,
    position: "absolute",
  },
  text: {
    top: 140,
  },
  text1: {
    top: 188,
  },
  rectangleParent: {
    top: 89,
    left: 30,
    height: 228,
    width: 333,
    position: "absolute",
  },
});

export default GroupComponent9;
