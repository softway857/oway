import React, { useMemo } from "react";
import { Image, StyleSheet, View } from "react-native";
import Thumb from "../assets/thumb.svg";
import { StyleVariable, Color } from "../GlobalStyles";

export type Switch1Type = {
  /** Variant props */
  checked?: string;

  /** Style props */
  switchTop?: number | string;
  switchLeft?: number | string;
};

const getStyleValue = (key: string, value: string | number | undefined) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Switch1 = ({ checked = "off", switchTop, switchLeft }: Switch1Type) => {
  const switchStyle = useMemo(() => {
    return {
      ...getStyleValue("top", switchTop),
      ...getStyleValue("left", switchLeft),
    };
  }, [switchTop, switchLeft]);

  return (
    <View style={[styles.switch, switchStyle]}>
      <Thumb style={styles.thumbIcon} />
    </View>
  );
};

const styles = StyleSheet.create({
  thumbIcon: {
    width: StyleVariable.spacing5,
    height: StyleVariable.spacing5,
  },
  switch: {
    position: "absolute",
    top: 19,
    left: 273,
    borderRadius: StyleVariable.borderRadiusFull,
    backgroundColor: Color.textColor,
    width: StyleVariable.spacing11,
    height: StyleVariable.spacing6,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
    padding: StyleVariable.spacing05,
  },
});

export default Switch1;
