import * as React from "react";
import { StyleSheet, View, Image, Text, Pressable } from "react-native";
import InputFields from "./InputFields";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import GroupComponent from "./GroupComponent";
import { Border, Color, Gap, FontSize, FontFamily } from "../GlobalStyles";

const GroupComponent5 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.groupParent}>
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.framePosition]} />
        <View style={styles.flagUsasvgParent}>
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg4.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/russiasvg.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg1.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg2.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg3.png")}
          />
        </View>
        <View style={styles.groupItem} />
      </View>
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={91}
        inputFieldsLeft={0}
        inputFieldsMarginLeft="unset"
        inputFieldsWidth={333}
        placeholder1="Քաշ (կգ)"
        showPlaceholder
        placeholder2="Քաշ (կգ)"
        placeholderFontWeight="unset"
      />
      <Text style={styles.text}>Գերծավալային քաշ</Text>
      <Pressable
        style={[styles.frame, styles.framePosition]}
        onPress={() => navigation.navigate("Overweight")}
      />
      <GroupComponent groupViewTop={242} />
    </View>
  );
};

const styles = StyleSheet.create({
  groupChildLayout: {
    height: 70,
    top: 0,
    width: 333,
  },
  framePosition: {
    shadowOpacity: 1,
    left: 0,
    position: "absolute",
  },
  groupChild: {
    shadowColor: "rgba(0, 0, 0, 0.05)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 2,
    elevation: 2,
    borderRadius: Border.br_6xs,
    backgroundColor: Color.themeBackground,
    height: 70,
    top: 0,
    width: 333,
    shadowOpacity: 1,
  },
  flagUsasvgIcon: {
    width: 45,
    height: 27,
    overflow: "hidden",
  },
  flagUsasvgParent: {
    top: 22,
    left: 17,
    flexDirection: "row",
    alignItems: "center",
    gap: Gap.gap_xl,
    position: "absolute",
  },
  groupItem: {
    top: 56,
    left: 13,
    backgroundColor: Color.color2,
    width: 2,
    height: 54,
    transform: [
      {
        rotate: "-90deg",
      },
    ],
    position: "absolute",
  },
  rectangleParent: {
    left: 0,
    height: 70,
    top: 0,
    position: "absolute",
  },
  text: {
    marginLeft: -136.5,
    top: 179,
    left: "50%",
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.montserratArm,
    color: Color.textColor,
    textAlign: "left",
    position: "absolute",
  },
  frame: {
    top: 175,
    shadowColor: "rgba(0, 0, 0, 0.07)",
    shadowOffset: {
      width: 0,
      height: 7,
    },
    shadowRadius: 64,
    elevation: 64,
    borderRadius: Border.br_9xs,
    borderStyle: "solid",
    borderColor: Color.strokeColor,
    borderWidth: 1,
    width: 24,
    height: 24,
  },
  groupParent: {
    top: 88,
    left: 30,
    height: 292,
    width: 333,
    position: "absolute",
  },
});

export default GroupComponent5;
