import * as React from "react";
import { Image, StyleSheet, Text, View, Pressable } from "react-native";
import InputFields from "./InputFields";
import Group12525 from "../assets/group-12525.svg";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import PrimaryButton from "./PrimaryButton";
import { Color, FontFamily, FontSize } from "../GlobalStyles";

const GroupComponent12 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.inputFieldsParent}>
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={54}
        inputFieldsLeft={0}
        inputFieldsMarginLeft="unset"
        inputFieldsWidth={333}
        placeholder1="Էլ․ հասցե"
        showPlaceholder
        placeholder2="Էլ․ հասցե"
        placeholderFontWeight="unset"
      />
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={153}
        inputFieldsLeft={0}
        inputFieldsMarginLeft="unset"
        inputFieldsWidth={333}
        placeholder1="Գաղտնաբառ"
        showPlaceholder
        placeholder2="Գաղտնաբառ"
        placeholderFontWeight="unset"
      />
      <Group12525 style={styles.groupChild} width={18} height={18} />
      <Pressable
        style={styles.wrapper}
        onPress={() => navigation.navigate("ForgotPassword")}
      >
        <Text style={[styles.text, styles.textPosition]}>
          Մոռացե ՞լ եք գաղտնաբառը։
        </Text>
      </Pressable>
      <PrimaryButton
        color="Cyan"
        size="default"
        state="Default"
        primaryButtonTop={283}
        button="Մուտք"
      />
      <Text style={[styles.text1, styles.textPosition]}>Մուտք</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  textPosition: {
    color: Color.colorBlack,
    fontFamily: FontFamily.montserratArm,
    top: 0,
    position: "absolute",
  },
  groupChild: {
    top: 193,
    left: 303,
    position: "absolute",
  },
  text: {
    left: 0,
    fontSize: FontSize.size_xs,
    textAlign: "left",
  },
  wrapper: {
    top: 238,
    left: 148,
    width: 185,
    height: 15,
    position: "absolute",
  },
  text1: {
    marginLeft: -35.5,
    left: "50%",
    fontSize: FontSize.size_xl,
    fontWeight: "500",
    textAlign: "center",
  },
  inputFieldsParent: {
    top: 188,
    left: 30,
    width: 333,
    height: 333,
    position: "absolute",
  },
});

export default GroupComponent12;
