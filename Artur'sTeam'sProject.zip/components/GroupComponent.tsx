import React, { useMemo } from "react";
import { StyleSheet, View } from "react-native";
import InputFields from "./InputFields";

export type GroupComponentType = {
  /** Style props */
  groupViewTop?: number | string;
};

const getStyleValue = (key: string, value: string | number | undefined) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const GroupComponent = ({ groupViewTop }: GroupComponentType) => {
  const groupViewStyle = useMemo(() => {
    return {
      ...getStyleValue("top", groupViewTop),
    };
  }, [groupViewTop]);

  return (
    <View style={[styles.inputFieldsWrapper, groupViewStyle]}>
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={0}
        inputFieldsLeft={0}
        inputFieldsMarginLeft="unset"
        inputFieldsWidth={333}
        inputFieldsElevation={4}
        showPlaceholder={false}
        placeholder2="Առաքման արժեք                           ——— դր"
        placeholderFontWeight="700"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  inputFieldsWrapper: {
    position: "absolute",
    top: 505,
    left: 0,
    width: 333,
    height: 50,
  },
});

export default GroupComponent;
