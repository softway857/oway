import * as React from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import Lucidehouseplus from "../assets/lucidehouseplus.svg";
import Lucideplanetakeoff from "../assets/lucideplanetakeoff.svg";
import GroupComponent2 from "./GroupComponent2";
import Lucidepackageopen from "../assets/lucidepackageopen.svg";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const GroupComponent10 = () => {
  return (
    <View style={styles.rectangleParent}>
      <View style={[styles.groupChild, styles.groupChildPosition]} />
      <View style={[styles.lucidehousePlusParent, styles.parentPosition]}>
        <Lucidehouseplus
          style={[styles.lucidehousePlusIcon, styles.groupChildPosition]}
          width={24}
          height={24}
        />
        <Text style={[styles.text, styles.textTypo1]}>Հասել է պահեստ</Text>
        <Text style={[styles.text1, styles.textClr]}>{`07/07/2024 `}</Text>
      </View>
      <View style={[styles.lucideplaneTakeoffParent, styles.parentPosition]}>
        <Lucideplanetakeoff
          style={[styles.lucidehousePlusIcon, styles.groupChildPosition]}
          width={24}
          height={24}
        />
        <Text style={[styles.text2, styles.textTypo]}>Ճանապարհին է</Text>
        <Text style={[styles.text3, styles.textTypo]}>{`07/07/2024 `}</Text>
      </View>
      <GroupComponent2 groupViewTop={181} />
      <View style={[styles.lucidepackageOpenParent, styles.parentPosition]}>
        <Lucidepackageopen
          style={[styles.lucidehousePlusIcon, styles.groupChildPosition]}
          width={24}
          height={24}
        />
        <Text style={[styles.text2, styles.textTypo]}>Ընդունված է</Text>
        <Text style={[styles.text3, styles.textTypo]}>{`07/07/2024 `}</Text>
      </View>
      <View style={[styles.groupItem, styles.groupLayout]} />
      <View style={[styles.groupInner, styles.groupLayout]} />
      <View style={[styles.lineView, styles.groupLayout]} />
    </View>
  );
};

const styles = StyleSheet.create({
  groupChildPosition: {
    left: 0,
    position: "absolute",
  },
  parentPosition: {
    height: 53,
    left: 22,
    position: "absolute",
  },
  textTypo1: {
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
    fontSize: FontSize.size_sm,
    left: 37,
    position: "absolute",
  },
  textClr: {
    color: Color.textColor,
    fontWeight: "500",
    top: 28,
  },
  textTypo: {
    left: 33,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  groupLayout: {
    height: 55,
    width: 1,
    borderRightWidth: 1,
    borderRadius: 0.001,
    borderColor: Color.colorDarkgray,
    borderStyle: "dashed",
    left: 34,
    position: "absolute",
  },
  groupChild: {
    shadowColor: "rgba(143, 143, 143, 0.25)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 3,
    elevation: 3,
    shadowOpacity: 1,
    borderRadius: Border.br_8xs,
    backgroundColor: Color.themeBackground,
    top: 0,
    left: 0,
    height: 331,
    width: 333,
  },
  lucidehousePlusIcon: {
    top: 15,
    overflow: "hidden",
  },
  text: {
    color: Color.colorGray_100,
    top: 0,
  },
  text1: {
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
    fontSize: FontSize.size_sm,
    left: 37,
    position: "absolute",
  },
  lucidehousePlusParent: {
    top: 13,
    width: 168,
  },
  text2: {
    color: Color.colorGray_100,
    top: 0,
  },
  text3: {
    color: Color.textColor,
    fontWeight: "500",
    top: 28,
  },
  lucideplaneTakeoffParent: {
    top: 97,
    width: 159,
  },
  lucidepackageOpenParent: {
    top: 265,
    width: 132,
  },
  groupItem: {
    top: 56,
  },
  groupInner: {
    top: 140,
  },
  lineView: {
    top: 224,
  },
  rectangleParent: {
    top: 333,
    left: 30,
    height: 331,
    width: 333,
    position: "absolute",
  },
});

export default GroupComponent10;
