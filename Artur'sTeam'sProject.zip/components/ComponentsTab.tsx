import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import BadgeCount from "./BadgeCount";
import {
  FontSize,
  FontFamily,
  Color,
  Border,
  Padding,
  Gap,
} from "../GlobalStyles";

export type ComponentsTabType = {
  tabOne?: string;

  /** Variant props */
  count?: boolean;
  property1?: string;

  /** Style props */
  componentsTab2Flex?: number | string;
  componentsTab2BorderStyle?: string;
  componentsTab2BorderColor?: string;
  componentsTab2BorderBottomWidth?: number | string;
  tabOneFontWeight?: string;
};

const getStyleValue = (key: string, value: string | number | undefined) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const ComponentsTab = ({
  count = false,
  property1 = "Active",
  componentsTab2Flex,
  componentsTab2BorderStyle,
  componentsTab2BorderColor,
  componentsTab2BorderBottomWidth,
  tabOne,
  tabOneFontWeight,
}: ComponentsTabType) => {
  const componentsTab2Style = useMemo(() => {
    return {
      ...getStyleValue("flex", componentsTab2Flex),
      ...getStyleValue("borderStyle", componentsTab2BorderStyle),
      ...getStyleValue("borderColor", componentsTab2BorderColor),
      ...getStyleValue("borderBottomWidth", componentsTab2BorderBottomWidth),
    };
  }, [
    componentsTab2Flex,
    componentsTab2BorderStyle,
    componentsTab2BorderColor,
    componentsTab2BorderBottomWidth,
  ]);

  const tabOneStyle = useMemo(() => {
    return {
      ...getStyleValue("fontWeight", tabOneFontWeight),
    };
  }, [tabOneFontWeight]);

  return (
    <View style={[styles.componentsTab2, componentsTab2Style]}>
      <Text style={[styles.tabOne, styles.textTypo, tabOneStyle]}>
        {tabOne}
      </Text>
      <LinearGradient
        style={styles.wrapper}
        locations={[0, 1]}
        colors={["#3da8bf", "#229db8"]}
        useAngle={true}
        angle={90}
      >
        <Text style={[styles.text, styles.textTypo]}>2</Text>
      </LinearGradient>
      <BadgeCount
        property1="Filled"
        size="Small"
        showBadgeCount={false}
        badgeCountMarginTop="unset"
        badgeCountPosition="unset"
        badgeCountMarginLeft="unset"
        badgeCountTop="unset"
        badgeCountLeft="unset"
        badgeCountBorderRadius={70}
        badgeCountWidth="unset"
        badgeCountHeight="unset"
        label="0"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  textTypo: {
    textAlign: "center",
    fontWeight: "600",
  },
  tabOne: {
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.montserratArm,
    color: Color.darkMedium,
  },
  text: {
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorsCardBG,
  },
  wrapper: {
    borderRadius: Border.br_lgi,
    width: 18,
    height: 18,
    justifyContent: "center",
    display: "none",
    backgroundColor: Color.colorsPrimary,
    alignItems: "center",
  },
  componentsTab2: {
    flex: 1,
    backgroundColor: Color.themeBackground,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderBottomWidth: 1,
    height: 40,
    flexDirection: "row",
    paddingHorizontal: Padding.p_base,
    paddingVertical: Padding.p_5xs,
    gap: Gap.gap_sm,
    alignItems: "center",
  },
});

export default ComponentsTab;
