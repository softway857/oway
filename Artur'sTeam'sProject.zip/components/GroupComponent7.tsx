import * as React from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import Emojioneflagforunitedstates from "../assets/emojioneflagforunitedstates.svg";
import Flagforarmeniasvgrepocom1 from "../assets/flagforarmenia-svgrepocom1.svg";
import Flagforrussiasvgrepocom from "../assets/flagforrussia-svgrepocom.svg";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const GroupComponent7 = () => {
  return (
    <View style={[styles.rectangleParent, styles.groupChildLayout]}>
      <View style={[styles.groupChild, styles.groupChildLayout]} />
      <Emojioneflagforunitedstates
        style={[styles.emojioneflagForUnitedStateIcon, styles.flagIconLayout]}
        width={32}
        height={32}
      />
      <Text style={styles.text}>Հայ</Text>
      <Text style={[styles.eng, styles.textTypo]}>Eng</Text>
      <Text style={[styles.text1, styles.textTypo]}>Рус</Text>
      <Flagforarmeniasvgrepocom1
        style={[styles.flagForArmeniaSvgrepocomIcon, styles.flagIconLayout]}
        width={32}
        height={32}
      />
      <Text style={[styles.text2, styles.textTypo]}>Ընտրել լեզուն</Text>
      <Flagforrussiasvgrepocom
        style={[styles.flagForRussiaSvgrepocomIcon, styles.flagIconLayout]}
        width={32}
        height={32}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  groupChildLayout: {
    height: 227,
    width: 392,
    position: "absolute",
  },
  flagIconLayout: {
    overflow: "hidden",
    height: 32,
    width: 32,
    top: 93,
    position: "absolute",
  },
  textTypo: {
    color: Color.colorBlack,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  groupChild: {
    top: 0,
    left: 0,
    shadowColor: "rgba(96, 96, 96, 0.12)",
    shadowOffset: {
      width: 4,
      height: 0,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    borderTopLeftRadius: Border.br_21xl,
    borderTopRightRadius: Border.br_21xl,
    backgroundColor: Color.themeBackground,
  },
  emojioneflagForUnitedStateIcon: {
    left: 180,
  },
  text: {
    left: 85,
    fontWeight: "500",
    color: Color.color2,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
    fontSize: FontSize.size_base,
    top: 130,
    position: "absolute",
  },
  eng: {
    fontWeight: "300",
    color: Color.colorBlack,
    top: 130,
    left: 180,
  },
  text1: {
    left: 276,
    fontWeight: "300",
    color: Color.colorBlack,
    top: 130,
  },
  flagForArmeniaSvgrepocomIcon: {
    left: 87,
  },
  text2: {
    top: 30,
    left: 133,
    fontWeight: "600",
  },
  flagForRussiaSvgrepocomIcon: {
    left: 273,
  },
  rectangleParent: {
    top: 680,
    left: 1,
  },
});

export default GroupComponent7;
