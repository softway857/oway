import * as React from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import Switch1 from "./Switch1";
import Lucidebell1 from "../assets/lucidebell1.svg";
import Flagforarmeniasvgrepocom from "../assets/flagforarmenia-svgrepocom.svg";
import Lucidelockkeyhole from "../assets/lucidelockkeyhole.svg";
import Lucideuserx from "../assets/lucideuserx.svg";
import {
  Color,
  Border,
  Gap,
  Padding,
  FontSize,
  FontFamily,
} from "../GlobalStyles";

const GroupComponent6 = () => {
  return (
    <View style={styles.rectangleParent}>
      <View style={[styles.groupChild, styles.groupShadowBox]} />
      <Switch1 checked="on" />
      <View style={[styles.groupItem, styles.groupShadowBox]} />
      <View style={[styles.groupInner, styles.groupShadowBox]} />
      <View style={[styles.rectangleView, styles.groupShadowBox]} />
      <View style={[styles.lucidebellParent, styles.parentFlexBox]}>
        <Lucidebell1 style={styles.lucidebellIcon} width={24} height={24} />
        <Text style={styles.text}>Ծանուցումներ</Text>
      </View>
      <View
        style={[styles.flagForArmeniaSvgrepocomParent, styles.parentFlexBox]}
      >
        <Flagforarmeniasvgrepocom
          style={styles.lucidebellIcon}
          width={24}
          height={24}
        />
        <Text style={styles.text}>Լեզու</Text>
      </View>
      <View style={[styles.lucidelockKeyholeParent, styles.parentFlexBox]}>
        <Lucidelockkeyhole
          style={styles.lucidebellIcon}
          width={24}
          height={24}
        />
        <Text style={styles.text}>Փոխել գաղտնաբառը</Text>
      </View>
      <View style={[styles.lucideuserXParent, styles.parentFlexBox]}>
        <Lucideuserx style={styles.lucidebellIcon} width={24} height={24} />
        <Text style={styles.text}>Ջնջել հաշիվը</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  groupShadowBox: {
    height: 61,
    backgroundColor: Color.themeBackground,
    borderRadius: Border.br_8xs,
    shadowOpacity: 1,
    elevation: 3,
    shadowRadius: 3,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(143, 143, 143, 0.25)",
    left: 0,
    width: 333,
    position: "absolute",
  },
  parentFlexBox: {
    gap: Gap.gap_md,
    padding: Padding.p_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    left: 20,
    position: "absolute",
  },
  groupChild: {
    top: 0,
  },
  groupItem: {
    top: 66,
  },
  groupInner: {
    top: 132,
  },
  rectangleView: {
    top: 198,
  },
  lucidebellIcon: {
    overflow: "hidden",
  },
  text: {
    fontSize: FontSize.size_base,
    lineHeight: 25,
    fontFamily: FontFamily.montserratArm,
    color: Color.textColor,
    textAlign: "left",
  },
  lucidebellParent: {
    top: 13,
  },
  flagForArmeniaSvgrepocomParent: {
    top: 79,
  },
  lucidelockKeyholeParent: {
    top: 145,
  },
  lucideuserXParent: {
    top: 211,
  },
  rectangleParent: {
    top: 92,
    left: 30,
    height: 259,
    width: 333,
    position: "absolute",
  },
});

export default GroupComponent6;
