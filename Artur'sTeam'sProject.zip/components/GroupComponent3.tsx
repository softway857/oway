import React, { useMemo } from "react";
import {
  StyleSheet,
  View,
  Text,
  Image,
  Pressable,
  ImageSourcePropType,
} from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Weighttoolsvgrepocom from "../assets/weighttool-svgrepocom.svg";
import { Border, FontFamily, Color, FontSize, Padding } from "../GlobalStyles";

export type GroupComponent3Type = {
  prop?: string;
  prop1?: string;
  chinassvgFill?: ImageSourcePropType;
  prop2?: string;

  /** Style props */
  groupPressableTop?: number | string;
  textLeft?: number | string;

  /** Action props */
  onGroupPressablePress?: () => void;
};

const getStyleValue = (key: string, value: string | number | undefined) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const GroupComponent3 = ({
  onGroupPressablePress,
  groupPressableTop,
  prop,
  prop1,
  chinassvgFill,
  prop2,
  textLeft,
}: GroupComponent3Type) => {
  const groupPressableStyle = useMemo(() => {
    return {
      ...getStyleValue("top", groupPressableTop),
    };
  }, [groupPressableTop]);

  const textStyle = useMemo(() => {
    return {
      ...getStyleValue("left", textLeft),
    };
  }, [textLeft]);

  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <Pressable
      style={[
        styles.rectangleParent,
        styles.groupChildLayout,
        groupPressableStyle,
      ]}
      onPress={onGroupPressablePress}
    >
      <View style={[styles.groupChild, styles.groupPosition]} />
      <Text style={[styles.text, styles.textTypo1]}>{prop}</Text>
      <Weighttoolsvgrepocom
        style={[styles.weightToolSvgrepocomIcon, styles.iconPosition]}
        width={16}
        height={16}
      />
      <Text style={[styles.text1, styles.textTypo]}>{prop1}</Text>
      <Image
        style={[styles.airplanesvgIcon, styles.iconPosition]}
        resizeMode="cover"
        source={require("../assets/airplanesvg.png")}
      />
      <View style={styles.yt343en3334Wrapper}>
        <Text style={[styles.yt343en3334, styles.textTypo1]}>YT343EN3334</Text>
      </View>
      <Image
        style={[styles.chinassvgFillIcon, styles.iconPosition]}
        resizeMode="cover"
        source={chinassvgFill}
      />
      <View style={styles.groupItem} />
      <View style={[styles.groupWrapper, styles.groupLayout]}>
        <View style={[styles.rectangleGroup, styles.groupLayout]}>
          <View style={[styles.groupInner, styles.groupLayout]} />
          <Text style={[styles.text2, styles.textTypo, textStyle]}>
            {prop2}
          </Text>
        </View>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  groupChildLayout: {
    height: 80,
    width: 333,
    position: "absolute",
  },
  groupPosition: {
    borderRadius: Border.br_8xs,
    left: 0,
    top: 0,
  },
  textTypo1: {
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
  },
  iconPosition: {
    overflow: "hidden",
    position: "absolute",
  },
  textTypo: {
    fontWeight: "500",
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    position: "absolute",
  },
  groupLayout: {
    height: 21,
    width: 65,
    position: "absolute",
  },
  groupChild: {
    shadowColor: "rgba(143, 143, 143, 0.25)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 3,
    elevation: 3,
    shadowOpacity: 1,
    backgroundColor: Color.themeBackground,
    height: 80,
    width: 333,
    position: "absolute",
  },
  text: {
    top: 16,
    left: 281,
    color: Color.colorBlack,
    lineHeight: 11,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  weightToolSvgrepocomIcon: {
    top: 13,
    left: 259,
  },
  text1: {
    left: 79,
    lineHeight: 23,
    color: Color.textColor,
    fontSize: FontSize.size_sm,
    top: 43,
  },
  airplanesvgIcon: {
    bottom: 12,
    left: 18,
    maxHeight: "100%",
    width: 25,
    top: 43,
  },
  yt343en3334: {
    lineHeight: 25,
    color: Color.colorGray_300,
    fontSize: FontSize.size_sm,
  },
  yt343en3334Wrapper: {
    top: 3,
    left: 15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: Padding.p_8xs,
    position: "absolute",
  },
  chinassvgFillIcon: {
    top: 48,
    left: 51,
    width: 22,
    height: 13,
  },
  groupItem: {
    top: 46,
    left: 44,
    borderStyle: "solid",
    borderColor: Color.colorGainsboro,
    borderRightWidth: 1,
    width: 1,
    height: 19,
    position: "absolute",
  },
  groupInner: {
    backgroundColor: Color.color2,
    borderRadius: Border.br_8xs,
    left: 0,
    top: 0,
  },
  text2: {
    top: 5,
    left: 9,
    color: Color.themeBackground,
    lineHeight: 11,
    fontSize: FontSize.size_xs,
  },
  rectangleGroup: {
    left: 0,
    top: 0,
    width: 65,
  },
  groupWrapper: {
    top: 45,
    left: 251,
  },
  rectangleParent: {
    top: 92,
    left: 30,
  },
});

export default GroupComponent3;
