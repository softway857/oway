import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Group15 from "../assets/group-15.svg";
import GroupComponent3 from "../components/GroupComponent3";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const InArmenia = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.inArmenia}>
      <View style={styles.inArmeniaChild} />
      <Text style={styles.text}>Հայաստանում է</Text>
      <Group15 style={styles.inArmeniaItem} width={40} height={40} />
      <GroupComponent3
        onGroupPressablePress={() => navigation.navigate("Settings")}
        groupPressableTop={92}
        prop="0,2կգ"
        prop1="Չինաստան"
        chinassvgFill={require("../assets/chinassvg-fill.png")}
        prop2="1000դր"
        textLeft={9}
      />
      <GroupComponent3
        onGroupPressablePress={() => navigation.navigate("Settings")}
        groupPressableTop={187}
        prop="0,1կգ"
        prop1="Իսպանիա"
        chinassvgFill={require("../assets/chinassvg-fill2.png")}
        prop2="480դր"
        textLeft={12}
      />
      <GroupComponent3
        onGroupPressablePress={() => navigation.navigate("Settings")}
        groupPressableTop={282}
        prop="0,3կգ"
        prop1="Իսպանիա"
        chinassvgFill={require("../assets/chinassvg-fill2.png")}
        prop2="1440դր"
        textLeft={9}
      />
      <GroupComponent3
        onGroupPressablePress={() => navigation.navigate("Settings")}
        groupPressableTop={377}
        prop="0,4կգ"
        prop1="Չինաստան"
        chinassvgFill={require("../assets/chinassvg-fill.png")}
        prop2="2000դր"
        textLeft={9}
      />
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  inArmeniaChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_60xl,
    backgroundColor: Color.color2,
    width: 426,
    height: 158,
    position: "absolute",
  },
  text: {
    top: 32,
    left: 85,
    fontSize: FontSize.size_lg,
    lineHeight: 25,
    fontWeight: "500",
    fontFamily: FontFamily.montserratArm,
    color: Color.textColor,
    textAlign: "left",
    position: "absolute",
  },
  inArmeniaItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  inArmenia: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default InArmenia;
