import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import Group15 from "../assets/group-15.svg";
import { Color, FontFamily, Border, FontSize } from "../GlobalStyles";

const Store = () => {
  return (
    <View style={styles.store}>
      <View style={[styles.storeChild, styles.storeBg]} />
      <Text style={[styles.text, styles.textTypo]}>Խանութներ</Text>
      <Text style={[styles.text1, styles.textTypo]}>
        Կատարիր առցանց գնումներ աշխարհի թոփ խանութներից
      </Text>
      <Group15
        style={[styles.storeItem, styles.parentPosition]}
        width={40}
        height={40}
      />
      <View style={[styles.parent, styles.parentPosition]}>
        <Text style={styles.text2}>Բոլորը</Text>
        <Image
          style={styles.flagUsasvgIcon}
          resizeMode="cover"
          source={require("../assets/flagusasvg5.png")}
        />
        <Image
          style={styles.flagUsasvgIcon}
          resizeMode="cover"
          source={require("../assets/flagusasvg6.png")}
        />
        <Image
          style={styles.flagUsasvgIcon}
          resizeMode="cover"
          source={require("../assets/flagusasvg7.png")}
        />
        <Image
          style={styles.flagUsasvgIcon}
          resizeMode="cover"
          source={require("../assets/flagusasvg8.png")}
        />
        <Image
          style={styles.flagUsasvgIcon}
          resizeMode="cover"
          source={require("../assets/flagusasvg9.png")}
        />
      </View>
      <View style={[styles.storeInner, styles.storeBg]} />
      <Image
        style={[styles.shop1svgIcon, styles.shop1svgIconPosition]}
        resizeMode="cover"
        source={require("../assets/shop-1svg.png")}
      />
      <Image
        style={[styles.shop1svgIcon1, styles.shop1svgIconPosition]}
        resizeMode="cover"
        source={require("../assets/shop-1svg.png")}
      />
      <Image
        style={[styles.shop1svgIcon2, styles.shop1svgIconPosition]}
        resizeMode="cover"
        source={require("../assets/shop-1svg.png")}
      />
      <Image
        style={[styles.shop1svgIcon3, styles.shop1svgIconPosition]}
        resizeMode="cover"
        source={require("../assets/shop-1svg.png")}
      />
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  storeBg: {
    backgroundColor: Color.color2,
    position: "absolute",
  },
  textTypo: {
    textAlign: "left",
    left: 85,
    fontFamily: FontFamily.montserratArm,
    position: "absolute",
  },
  parentPosition: {
    left: 30,
    position: "absolute",
  },
  shop1svgIconPosition: {
    height: 138,
    width: 337,
    marginLeft: -166.5,
    left: "50%",
    position: "absolute",
    overflow: "hidden",
  },
  storeChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    width: 426,
    height: 158,
  },
  text: {
    top: 32,
    fontSize: FontSize.size_lg,
    lineHeight: 25,
    fontWeight: "500",
    color: Color.textColor,
  },
  text1: {
    top: 69,
    fontSize: FontSize.size_xs,
    color: "rgba(0, 0, 0, 0.56)",
    width: 271,
  },
  storeItem: {
    top: 24,
  },
  text2: {
    fontSize: 11,
    fontWeight: "600",
    color: Color.darkMedium,
    textAlign: "center",
    fontFamily: FontFamily.montserratArm,
  },
  flagUsasvgIcon: {
    width: 38,
    height: 23,
    overflow: "hidden",
  },
  parent: {
    top: 213,
    flexDirection: "row",
    alignItems: "center",
    gap: 18,
  },
  storeInner: {
    top: 236,
    left: 31,
    width: 2,
    height: 41,
    transform: [
      {
        rotate: "-90deg",
      },
    ],
  },
  shop1svgIcon: {
    top: 254,
  },
  shop1svgIcon1: {
    top: 407,
  },
  shop1svgIcon2: {
    top: 560,
  },
  shop1svgIcon3: {
    top: 713,
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    left: "50%",
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  store: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default Store;
