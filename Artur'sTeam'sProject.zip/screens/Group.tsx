import * as React from "react";
import { Image, StyleSheet, View } from "react-native";
import Path1 from "../assets/path1.svg";
import TextArea from "../components/TextArea";

const Group = () => {
  return (
    <View style={styles.pathParent}>
      <Path1 style={styles.pathIcon} width={3} height={6} />
      <TextArea placeholder state="default" />
    </View>
  );
};

const styles = StyleSheet.create({
  pathIcon: {
    position: "absolute",
    top: "0%",
    right: "95.5%",
    bottom: "94.47%",
    left: "1.5%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
  },
  pathParent: {
    flex: 1,
    width: "100%",
    height: 132,
  },
});

export default Group;
