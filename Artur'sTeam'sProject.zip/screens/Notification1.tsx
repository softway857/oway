import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import Group15 from "../assets/group-15.svg";
import ComponentsTab from "../components/ComponentsTab";
import GroupComponent4 from "../components/GroupComponent4";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const Notification1 = () => {
  return (
    <View style={styles.notification}>
      <View style={styles.notificationChild} />
      <Text style={styles.text}>Ծանուցումներ</Text>
      <Group15 style={styles.notificationItem} width={40} height={40} />
      <View style={styles.lucideuserRound} />
      <View style={[styles.iphoneIndicator, styles.iphoneIndicatorLayout]}>
        <View style={styles.line} />
      </View>
      <View style={[styles.componentsTab2Parent, styles.iphoneIndicatorLayout]}>
        <ComponentsTab count property1="Inactive" tabOne="Նոր" />
        <ComponentsTab
          count
          property1="Inactive"
          componentsTab2BorderStyle="unset"
          componentsTab2BorderColor="unset"
          tabOne="Կարդացված"
          tabOneFontWeight="unset"
        />
      </View>
      <GroupComponent4 />
      <GroupComponent4 groupViewTop={251} />
      <GroupComponent4 groupViewTop={341} />
      <GroupComponent4 groupViewTop={431} />
      <GroupComponent4 groupViewTop={521} />
    </View>
  );
};

const styles = StyleSheet.create({
  iphoneIndicatorLayout: {
    width: 393,
    position: "absolute",
  },
  notificationChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    backgroundColor: Color.color2,
    width: 426,
    height: 158,
    position: "absolute",
  },
  text: {
    top: 32,
    left: 85,
    fontSize: FontSize.size_lg,
    lineHeight: 25,
    fontWeight: "500",
    fontFamily: FontFamily.montserratArm,
    color: Color.textColor,
    textAlign: "left",
    position: "absolute",
  },
  notificationItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  lucideuserRound: {
    top: 35,
    left: 182,
    width: 24,
    height: 24,
    position: "absolute",
    overflow: "hidden",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    height: 30,
  },
  componentsTab2Parent: {
    top: 86,
    left: 0,
    shadowColor: "rgba(0, 0, 0, 0.03)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 2,
    elevation: 2,
    shadowOpacity: 1,
    height: 60,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 70,
    paddingVertical: 0,
    gap: 40,
    backgroundColor: Color.bgColor,
  },
  notification: {
    borderRadius: Border.br_21xl,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
    backgroundColor: Color.bgColor,
  },
});

export default Notification1;
