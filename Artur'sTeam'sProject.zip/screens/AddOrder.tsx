import * as React from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import Lucidebell from "../assets/lucidebell.svg";
import InputFields from "../components/InputFields";
import Attentionsvgrepocom from "../assets/attention-svgrepocom.svg";
import PrimaryButton from "../components/PrimaryButton";
import { Color, FontFamily, Border, FontSize, Gap } from "../GlobalStyles";

const AddOrder = () => {
  return (
    <View style={styles.addOrder}>
      <View style={[styles.addOrderChild, styles.groupInnerBg]} />
      <Lucidebell style={styles.lucidebellIcon} width={32} height={32} />
      <Text style={[styles.text, styles.textTypo]}>Ավելացնել պատվեր</Text>
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={173}
        inputFieldsLeft={30}
        inputFieldsMarginLeft="unset"
        inputFieldsWidth={333}
        placeholder1="Tracking համար"
        showPlaceholder
        placeholder2="Tracking համար"
        placeholderFontWeight="unset"
      />
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={267}
        inputFieldsLeft={30}
        inputFieldsMarginLeft="unset"
        inputFieldsWidth={333}
        placeholder1="Անուն"
        showPlaceholder
        placeholder2="Անուն"
        placeholderFontWeight="unset"
      />
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={361}
        inputFieldsLeft={30}
        inputFieldsMarginLeft="unset"
        inputFieldsWidth={215}
        placeholder1="Արժեք"
        showPlaceholder
        placeholder2="Արժեք"
        placeholderFontWeight="unset"
      />
      <Attentionsvgrepocom
        style={styles.attentionSvgrepocomIcon}
        width={16}
        height={16}
      />
      <PrimaryButton
        color="Cyan"
        size="default"
        state="Default"
        primaryButtonTop={602}
        primaryButtonLeft={30}
        button="Ավելացնել"
      />
      <View style={[styles.addOrderInner, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.groupShadowBox]} />
      </View>
      <Text
        style={[styles.text1, styles.textTypo]}
      >{`Մուտագրվող գինը հանդիսանում է տվյալ առաքանիում գտնվող պատվերների ձեռք բերման ընդհանուր արժեքը։ Տվյալները ավտոմատիզացված կերպով ուղարկվում են մաքսատուն և մուտքագրելուց հետո ենթակա չեն փոփոխության:
`}</Text>
      <View style={[styles.rectangleParent, styles.groupItemLayout]}>
        <View style={[styles.groupItem, styles.groupItemLayout]} />
        <View style={styles.flagUsasvgParent}>
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg4.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/russiasvg.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg1.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg2.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg3.png")}
          />
        </View>
        <View style={[styles.groupInner, styles.groupInnerBg]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  groupInnerBg: {
    backgroundColor: Color.color2,
    position: "absolute",
  },
  textTypo: {
    fontFamily: FontFamily.montserratArm,
    position: "absolute",
  },
  groupChildLayout: {
    height: 143,
    width: 268,
    position: "absolute",
  },
  groupShadowBox: {
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    left: 0,
    top: 0,
  },
  groupItemLayout: {
    height: 70,
    width: 333,
    position: "absolute",
  },
  addOrderChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    width: 426,
    height: 158,
  },
  lucidebellIcon: {
    top: 19,
    left: 334,
    position: "absolute",
    overflow: "hidden",
  },
  text: {
    marginLeft: -88.5,
    top: 37,
    left: "50%",
    fontSize: FontSize.size_base,
    fontWeight: "500",
    color: Color.textColor,
    textAlign: "center",
  },
  attentionSvgrepocomIcon: {
    top: 364,
    left: 87,
    position: "absolute",
    overflow: "hidden",
  },
  groupChild: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowRadius: 6,
    elevation: 6,
    borderRadius: 6,
    backgroundColor: "#eee",
    height: 143,
    width: 268,
    position: "absolute",
  },
  addOrderInner: {
    top: 212,
    left: 95,
  },
  text1: {
    top: 217,
    left: 104,
    fontSize: FontSize.size_xs,
    lineHeight: 17,
    fontWeight: "300",
    color: "rgba(0, 0, 0, 0.55)",
    textAlign: "left",
    width: 254,
    height: 118,
  },
  groupItem: {
    shadowColor: "rgba(0, 0, 0, 0.05)",
    shadowRadius: 2,
    elevation: 2,
    borderRadius: Border.br_6xs,
    backgroundColor: Color.themeBackground,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    left: 0,
    top: 0,
  },
  flagUsasvgIcon: {
    width: 45,
    height: 27,
    overflow: "hidden",
  },
  flagUsasvgParent: {
    top: 22,
    left: 17,
    flexDirection: "row",
    alignItems: "center",
    gap: Gap.gap_xl,
    position: "absolute",
  },
  groupInner: {
    top: 56,
    left: 13,
    width: 2,
    height: 54,
    transform: [
      {
        rotate: "-90deg",
      },
    ],
  },
  rectangleParent: {
    top: 88,
    left: 30,
  },
  addOrder: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default AddOrder;
