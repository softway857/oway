import * as React from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import Group15 from "../assets/group-15.svg";
import Weighttoolsvgrepocom from "../assets/weighttool-svgrepocom.svg";
import Lucidehouseplus from "../assets/lucidehouseplus.svg";
import Lucideplanetakeoff from "../assets/lucideplanetakeoff.svg";
import GroupComponent2 from "../components/GroupComponent2";
import { Color, Border, FontFamily, FontSize, Padding } from "../GlobalStyles";

const Settings2 = () => {
  return (
    <View style={styles.settings}>
      <View style={styles.settingsChild} />
      <Group15 style={styles.settingsItem} width={40} height={40} />
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
      <View style={[styles.groupParent, styles.parentLayout]}>
        <View style={[styles.rectangleParent, styles.rectanglePosition]}>
          <View style={[styles.groupChild, styles.groupShadowBox]} />
          <View style={[styles.groupItem, styles.groupShadowBox]} />
          <View style={[styles.groupInner, styles.groupShadowBox]} />
          <View style={[styles.yt343en3334Wrapper, styles.trackingPosition]}>
            <Text style={[styles.yt343en3334, styles.textTypo3]}>
              YT343EN3334
            </Text>
          </View>
          <Text style={[styles.tracking, styles.textTypo3]}>
            Tracking համար
          </Text>
          <Text style={[styles.text, styles.textParentPosition]}>Քաշ</Text>
          <Text style={[styles.text1, styles.textParentPosition]}>Գումար</Text>
        </View>
        <Text style={[styles.text2, styles.textClr]}>Չինաստան</Text>
        <Image
          style={[styles.airplanesvgIcon, styles.text2Position]}
          resizeMode="cover"
          source={require("../assets/airplanesvg.png")}
        />
        <Image
          style={styles.chinassvgFillIcon}
          resizeMode="cover"
          source={require("../assets/chinassvg-fill.png")}
        />
        <Text style={[styles.text3, styles.textTypo2]}>0,2կգ</Text>
        <Weighttoolsvgrepocom
          style={styles.weightToolSvgrepocomIcon}
          width={16}
          height={16}
        />
        <View style={styles.lineView} />
        <View style={[styles.groupWrapper, styles.groupLayout]}>
          <View style={[styles.rectangleGroup, styles.groupLayout]}>
            <View style={[styles.rectangleView, styles.groupLayout]} />
            <Text style={[styles.text4, styles.textTypo2]}>1000դր</Text>
          </View>
        </View>
        <View style={[styles.lucidehousePlusParent, styles.textParentPosition]}>
          <Lucidehouseplus
            style={[styles.lucidehousePlusIcon, styles.iconLayout]}
            width={24}
            height={24}
          />
          <Text style={[styles.text5, styles.textTypo1]}>Հասել է պահեստ</Text>
          <Text style={[styles.text6, styles.textTypo1]}>{`07/07/2024 `}</Text>
        </View>
        <View
          style={[styles.lucideplaneTakeoffParent, styles.textParentPosition]}
        >
          <Lucideplanetakeoff
            style={[styles.lucideplaneTakeoffIcon, styles.iconLayout]}
            width={24}
            height={24}
          />
          <Text style={[styles.text7, styles.textTypo]}>Ճանապարհին է</Text>
          <Text style={[styles.text8, styles.textTypo]}>{`07/07/2024 `}</Text>
        </View>
        <GroupComponent2 />
        <View style={[styles.groupChild1, styles.groupChildLayout]} />
        <View style={[styles.groupChild2, styles.groupChildLayout]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  parentLayout: {
    height: 503,
    width: 333,
    position: "absolute",
  },
  rectanglePosition: {
    left: 0,
    top: 0,
  },
  groupShadowBox: {
    backgroundColor: Color.themeBackground,
    shadowOpacity: 1,
    elevation: 3,
    shadowRadius: 3,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(143, 143, 143, 0.25)",
    borderRadius: Border.br_8xs,
    left: 0,
    width: 333,
    position: "absolute",
  },
  trackingPosition: {
    left: 20,
    position: "absolute",
  },
  textTypo3: {
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    fontSize: FontSize.size_sm,
  },
  textParentPosition: {
    left: 22,
    position: "absolute",
  },
  textClr: {
    color: Color.textColor,
    fontWeight: "500",
  },
  text2Position: {
    top: 9,
    position: "absolute",
  },
  textTypo2: {
    lineHeight: 11,
    fontSize: FontSize.size_xs,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    position: "absolute",
  },
  groupLayout: {
    height: 21,
    width: 65,
    position: "absolute",
  },
  iconLayout: {
    height: 24,
    width: 24,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  textTypo1: {
    left: 37,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  textTypo: {
    left: 33,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  groupChildLayout: {
    height: 55,
    borderRadius: 0.001,
    borderColor: Color.colorDarkgray,
    borderStyle: "dashed",
    left: 34,
    width: 1,
    borderRightWidth: 1,
    position: "absolute",
  },
  settingsChild: {
    top: -22,
    left: -16,
    borderRadius: Border.br_59xl,
    width: 426,
    height: 158,
    backgroundColor: Color.color2,
    position: "absolute",
  },
  settingsItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  groupChild: {
    height: 112,
    top: 0,
  },
  groupItem: {
    top: 121,
    height: 100,
  },
  groupInner: {
    top: 237,
    height: 266,
  },
  yt343en3334: {
    fontWeight: "600",
    color: Color.colorDarkslateblue,
    lineHeight: 25,
    fontFamily: FontFamily.montserratArm,
    fontSize: FontSize.size_sm,
  },
  yt343en3334Wrapper: {
    top: 68,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 0,
    paddingVertical: Padding.p_8xs,
  },
  tracking: {
    top: 43,
    color: Color.colorGray_100,
    lineHeight: 25,
    fontFamily: FontFamily.montserratArm,
    fontSize: FontSize.size_sm,
    left: 20,
    position: "absolute",
  },
  text: {
    top: 140,
    color: Color.colorGray_100,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    fontSize: FontSize.size_sm,
    lineHeight: 25,
  },
  text1: {
    top: 188,
    color: Color.colorGray_100,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    fontSize: FontSize.size_sm,
    lineHeight: 25,
  },
  rectangleParent: {
    height: 503,
    width: 333,
    position: "absolute",
  },
  text2: {
    left: 153,
    lineHeight: 23,
    top: 9,
    position: "absolute",
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    fontSize: FontSize.size_sm,
    color: Color.textColor,
  },
  airplanesvgIcon: {
    bottom: 469,
    left: 92,
    maxHeight: "100%",
    width: 25,
    overflow: "hidden",
  },
  chinassvgFillIcon: {
    top: 14,
    left: 125,
    width: 22,
    height: 13,
    position: "absolute",
    overflow: "hidden",
  },
  text3: {
    top: 147,
    left: 87,
    color: Color.colorBlack,
  },
  weightToolSvgrepocomIcon: {
    top: 144,
    left: 65,
    position: "absolute",
    overflow: "hidden",
  },
  lineView: {
    top: 12,
    left: 118,
    borderStyle: "solid",
    borderColor: Color.colorGainsboro,
    height: 19,
    width: 1,
    borderRightWidth: 1,
    position: "absolute",
  },
  rectangleView: {
    borderRadius: Border.br_8xs,
    width: 65,
    left: 0,
    top: 0,
    backgroundColor: Color.color2,
  },
  text4: {
    top: 5,
    left: 9,
    color: Color.themeBackground,
    fontWeight: "500",
    lineHeight: 11,
    fontSize: FontSize.size_xs,
  },
  rectangleGroup: {
    left: 0,
    top: 0,
  },
  groupWrapper: {
    top: 190,
    left: 90,
  },
  lucidehousePlusIcon: {
    top: 22,
  },
  text5: {
    color: Color.colorGray_100,
    top: 0,
  },
  text6: {
    top: 35,
    color: Color.textColor,
    fontWeight: "500",
  },
  lucidehousePlusParent: {
    top: 250,
    width: 168,
    height: 60,
  },
  lucideplaneTakeoffIcon: {
    top: 15,
  },
  text7: {
    color: Color.colorGray_100,
    top: 0,
  },
  text8: {
    top: 28,
    color: Color.textColor,
    fontWeight: "500",
  },
  lucideplaneTakeoffParent: {
    top: 341,
    width: 159,
    height: 53,
  },
  groupChild1: {
    top: 300,
  },
  groupChild2: {
    top: 384,
  },
  groupParent: {
    top: 89,
    left: 30,
  },
  settings: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default Settings2;
