import * as React from "react";
import { StyleSheet, View, Image } from "react-native";
import IsolationMode1 from "../components/IsolationMode1";
import Group151 from "../assets/group-151.svg";
import GroupComponent12 from "../components/GroupComponent12";
import { Color, Border } from "../GlobalStyles";

const Login = () => {
  return (
    <View style={styles.login}>
      <View style={[styles.loginChild, styles.loginChildLayout]} />
      <IsolationMode1 />
      <Group151 style={styles.loginItem} width={40} height={40} />
      <GroupComponent12 />
      <Image
        style={styles.loginInner}
        resizeMode="cover"
        source={require("../assets/group-34.png")}
      />
      <View style={[styles.iphoneIndicator, styles.loginChildLayout]}>
        <View style={styles.line} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  loginChildLayout: {
    width: 393,
    position: "absolute",
  },
  loginChild: {
    top: 0,
    left: 0,
    backgroundColor: Color.color2,
    height: 152,
  },
  loginItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  loginInner: {
    height: "14.88%",
    width: "61.58%",
    top: "1.87%",
    right: "33.33%",
    bottom: "83.24%",
    left: "5.09%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    height: 30,
  },
  login: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default Login;
