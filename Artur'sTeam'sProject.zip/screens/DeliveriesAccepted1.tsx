import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import Group15 from "../assets/group-15.svg";
import GroupComponent9 from "../components/GroupComponent9";
import Weighttoolsvgrepocom from "../assets/weighttool-svgrepocom.svg";
import GroupComponent10 from "../components/GroupComponent10";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const DeliveriesAccepted1 = () => {
  return (
    <View style={styles.deliveriesAccepted}>
      <View style={styles.deliveriesAcceptedChild} />
      <Text style={[styles.text, styles.textTypo1]}>Ընդունված առաքանիներ</Text>
      <Group15 style={styles.deliveriesAcceptedItem} width={40} height={40} />
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
      <GroupComponent9 />
      <Text style={[styles.text1, styles.text1Position]}>Չինաստան</Text>
      <Image
        style={[styles.airplanesvgIcon, styles.text1Position]}
        resizeMode="cover"
        source={require("../assets/airplanesvg.png")}
      />
      <Image
        style={styles.chinassvgFillIcon}
        resizeMode="cover"
        source={require("../assets/chinassvg-fill1.png")}
      />
      <Text style={[styles.text2, styles.textTypo]}>0,2կգ</Text>
      <Weighttoolsvgrepocom
        style={styles.weightToolSvgrepocomIcon}
        width={16}
        height={16}
      />
      <View style={styles.deliveriesAcceptedInner} />
      <View style={styles.groupView}>
        <View style={styles.groupChildPosition}>
          <View style={[styles.groupChild, styles.groupChildPosition]} />
          <Text style={[styles.text3, styles.textTypo]}>1000դր</Text>
        </View>
      </View>
      <GroupComponent10 />
    </View>
  );
};

const styles = StyleSheet.create({
  textTypo1: {
    textAlign: "left",
    color: Color.textColor,
    fontFamily: FontFamily.montserratArm,
    fontWeight: "500",
  },
  text1Position: {
    top: 98,
    position: "absolute",
  },
  textTypo: {
    lineHeight: 11,
    fontSize: FontSize.size_xs,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    position: "absolute",
  },
  groupChildPosition: {
    left: 0,
    top: 0,
    height: 21,
    width: 65,
    position: "absolute",
  },
  deliveriesAcceptedChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    width: 426,
    height: 158,
    backgroundColor: Color.color2,
    position: "absolute",
  },
  text: {
    top: 32,
    left: 85,
    fontSize: FontSize.size_lg,
    lineHeight: 25,
    position: "absolute",
  },
  deliveriesAcceptedItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  text1: {
    left: 183,
    fontSize: FontSize.size_sm,
    lineHeight: 23,
    textAlign: "left",
    color: Color.textColor,
    fontFamily: FontFamily.montserratArm,
    fontWeight: "500",
  },
  airplanesvgIcon: {
    bottom: 784,
    left: 122,
    maxHeight: "100%",
    width: 25,
    overflow: "hidden",
  },
  chinassvgFillIcon: {
    top: 103,
    left: 155,
    width: 22,
    height: 13,
    position: "absolute",
    overflow: "hidden",
  },
  text2: {
    top: 236,
    left: 117,
    color: Color.colorBlack,
  },
  weightToolSvgrepocomIcon: {
    top: 233,
    left: 95,
    position: "absolute",
    overflow: "hidden",
  },
  deliveriesAcceptedInner: {
    top: 101,
    left: 148,
    borderStyle: "solid",
    borderColor: Color.colorGainsboro,
    borderRightWidth: 1,
    width: 1,
    height: 19,
    position: "absolute",
  },
  groupChild: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.color2,
  },
  text3: {
    top: 5,
    left: 9,
    color: Color.themeBackground,
    fontWeight: "500",
    lineHeight: 11,
    fontSize: FontSize.size_xs,
  },
  groupView: {
    top: 279,
    left: 120,
    height: 21,
    width: 65,
    position: "absolute",
  },
  deliveriesAccepted: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default DeliveriesAccepted1;
