import * as React from "react";
import { StyleSheet, View, Image, Text, Pressable } from "react-native";
import Lucidebell from "../assets/lucidebell.svg";
import MenuList from "../components/MenuList";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Lucidecalculator from "../assets/lucidecalculator.svg";
import Lucideuserround from "../assets/lucideuserround.svg";
import Lucidesettings from "../assets/lucidesettings.svg";
import Lucidephone from "../assets/lucidephone.svg";
import Lucidelogout from "../assets/lucidelogout.svg";
import {
  Color,
  FontFamily,
  FontSize,
  Border,
  Gap,
  Padding,
} from "../GlobalStyles";

const More = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.more}>
      <View style={styles.moreChild} />
      <Lucidebell style={styles.lucidebellIcon} width={32} height={32} />
      <MenuList />
      <View style={styles.iphoneIndicator}>
        <View style={[styles.line, styles.linePosition]} />
      </View>
      <Text style={[styles.text, styles.textTypo]}>Ավելին</Text>
      <Pressable
        style={[styles.moreItem, styles.moreChildShadowBox]}
        onPress={() => navigation.navigate("ShippingCalculator")}
      />
      <View style={[styles.moreInner, styles.moreChildShadowBox]} />
      <View style={[styles.rectangleView, styles.moreChildShadowBox]} />
      <View style={[styles.moreChild1, styles.moreChildShadowBox]} />
      <View style={[styles.moreChild2, styles.moreChildShadowBox]} />
      <View style={[styles.lucidecalculatorParent, styles.parentFlexBox]}>
        <Lucidecalculator
          style={styles.lucidecalculatorIcon}
          width={24}
          height={24}
        />
        <Text style={[styles.text1, styles.textTypo]}>Հաշվիչ</Text>
      </View>
      <Pressable
        style={[styles.lucideuserRoundParent, styles.parentFlexBox]}
        onPress={() => navigation.navigate("PersonalInformation")}
      >
        <Lucideuserround
          style={styles.lucidecalculatorIcon}
          width={24}
          height={24}
        />
        <Text style={[styles.text1, styles.textTypo]}>Անձնական տվյալներ</Text>
      </Pressable>
      <Pressable
        style={[styles.lucidesettingsParent, styles.parentFlexBox]}
        onPress={() => navigation.navigate("Seetings")}
      >
        <Lucidesettings
          style={styles.lucidecalculatorIcon}
          width={24}
          height={24}
        />
        <Text style={[styles.text1, styles.textTypo]}>Կարգավորումներ</Text>
      </Pressable>
      <Pressable
        style={[styles.lucidephoneParent, styles.parentFlexBox]}
        onPress={() => navigation.navigate("ContactUs")}
      >
        <Lucidephone
          style={styles.lucidecalculatorIcon}
          width={24}
          height={24}
        />
        <Text style={[styles.text1, styles.textTypo]}>Կապ մեզ հետ</Text>
      </Pressable>
      <View style={[styles.lucidelogOutParent, styles.parentFlexBox]}>
        <Lucidelogout
          style={styles.lucidecalculatorIcon}
          width={24}
          height={24}
        />
        <Text style={[styles.text1, styles.textTypo]}>Դուրս գալ</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  linePosition: {
    left: "50%",
    position: "absolute",
  },
  textTypo: {
    color: Color.textColor,
    fontFamily: FontFamily.montserratArm,
    fontSize: FontSize.size_base,
  },
  moreChildShadowBox: {
    height: 61,
    width: 333,
    backgroundColor: Color.themeBackground,
    borderRadius: Border.br_8xs,
    shadowOpacity: 1,
    elevation: 3,
    shadowRadius: 3,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(143, 143, 143, 0.25)",
    left: 30,
    position: "absolute",
  },
  parentFlexBox: {
    gap: Gap.gap_md,
    padding: Padding.p_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    left: 50,
    position: "absolute",
  },
  moreChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    backgroundColor: Color.color2,
    width: 426,
    height: 158,
    position: "absolute",
  },
  lucidebellIcon: {
    top: 19,
    left: 334,
    position: "absolute",
    overflow: "hidden",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  text: {
    marginLeft: -31.5,
    top: 37,
    fontWeight: "500",
    textAlign: "center",
    left: "50%",
    position: "absolute",
  },
  moreItem: {
    top: 92,
  },
  moreInner: {
    top: 158,
  },
  rectangleView: {
    top: 224,
  },
  moreChild1: {
    top: 290,
  },
  moreChild2: {
    top: 420,
  },
  lucidecalculatorIcon: {
    overflow: "hidden",
  },
  text1: {
    lineHeight: 25,
    textAlign: "left",
  },
  lucidecalculatorParent: {
    top: 105,
  },
  lucideuserRoundParent: {
    top: 171,
  },
  lucidesettingsParent: {
    top: 237,
  },
  lucidephoneParent: {
    top: 303,
  },
  lucidelogOutParent: {
    top: 433,
  },
  more: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default More;
