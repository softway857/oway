import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import Group15 from "../assets/group-15.svg";
import GroupComponent8 from "../components/GroupComponent8";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const DeleteAccount = () => {
  return (
    <View style={styles.deleteAccount}>
      <View style={styles.deleteAccountChild} />
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
      <Text style={styles.text}>Ջնջել հաշիվը</Text>
      <Group15 style={styles.deleteAccountItem} width={40} height={40} />
      <Image
        style={styles.tom1Icon}
        resizeMode="cover"
        source={require("../assets/tom-11.png")}
      />
      <GroupComponent8 />
    </View>
  );
};

const styles = StyleSheet.create({
  deleteAccountChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    backgroundColor: Color.color2,
    width: 426,
    height: 158,
    position: "absolute",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  text: {
    top: 32,
    left: 86,
    fontSize: FontSize.size_lg,
    lineHeight: 25,
    fontWeight: "500",
    fontFamily: FontFamily.montserratArm,
    color: Color.textColor,
    textAlign: "left",
    position: "absolute",
  },
  deleteAccountItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  tom1Icon: {
    top: 17,
    left: 235,
    width: 152,
    height: 152,
    position: "absolute",
  },
  deleteAccount: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default DeleteAccount;
