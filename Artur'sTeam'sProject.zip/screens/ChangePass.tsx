import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import Group15 from "../assets/group-15.svg";
import InputFields from "../components/InputFields";
import Group12525 from "../assets/group-12525.svg";
import PrimaryButton from "../components/PrimaryButton";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const ChangePass = () => {
  return (
    <View style={styles.changePass}>
      <View style={styles.changePassChild} />
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
      <Text style={styles.text}>Փոխել գաղտնաբառը</Text>
      <Group15 style={styles.changePassItem} width={40} height={40} />
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={149}
        inputFieldsLeft="50%"
        inputFieldsMarginLeft={-166.5}
        inputFieldsWidth={333}
        placeholder1="Հին գաղտանաբառ"
        showPlaceholder
        placeholder2="Հին գաղտանաբառ"
        placeholderFontWeight="unset"
      />
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={243}
        inputFieldsLeft="50%"
        inputFieldsMarginLeft={-166.5}
        inputFieldsWidth={333}
        placeholder1="Նոր գաղտանաբառ"
        showPlaceholder
        placeholder2="Նոր գաղտանաբառ"
        placeholderFontWeight="unset"
      />
      <Group12525
        style={[styles.changePassInner, styles.changeLayout]}
        width={18}
        height={18}
      />
      <Group12525
        style={[styles.groupIcon, styles.changeLayout]}
        width={18}
        height={18}
      />
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={337}
        inputFieldsLeft="50%"
        inputFieldsMarginLeft={-166.5}
        inputFieldsWidth={333}
        placeholder1="Կրկնել նոր գաղտանաբառը"
        showPlaceholder
        placeholder2="Կրկնել նոր գաղտանաբառը"
        placeholderFontWeight="unset"
      />
      <PrimaryButton
        color="Cyan"
        size="default"
        state="Default"
        primaryButtonTop={431}
        primaryButtonLeft={30}
        button="Փոխել"
      />
      <Group12525
        style={[styles.changePassChild1, styles.changeLayout]}
        width={18}
        height={18}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  changeLayout: {
    height: 18,
    width: 18,
    left: 333,
    position: "absolute",
  },
  changePassChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    backgroundColor: Color.color2,
    width: 426,
    height: 158,
    position: "absolute",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  text: {
    top: 32,
    left: 86,
    fontSize: FontSize.size_lg,
    lineHeight: 25,
    fontWeight: "500",
    fontFamily: FontFamily.montserratArm,
    color: Color.textColor,
    textAlign: "left",
    position: "absolute",
  },
  changePassItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  changePassInner: {
    top: 283,
  },
  groupIcon: {
    top: 187,
  },
  changePassChild1: {
    top: 377,
  },
  changePass: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default ChangePass;
