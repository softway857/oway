import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import Group15 from "../assets/group-15.svg";
import GroupComponent5 from "../components/GroupComponent5";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const ShippingCalculator = () => {
  return (
    <View style={styles.shippingCalculator}>
      <View style={styles.shippingCalculatorChild} />
      <Text style={styles.text}>Հաշվիչ</Text>
      <Group15 style={styles.shippingCalculatorItem} width={40} height={40} />
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
      <GroupComponent5 />
    </View>
  );
};

const styles = StyleSheet.create({
  shippingCalculatorChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    backgroundColor: Color.color2,
    width: 426,
    height: 158,
    position: "absolute",
  },
  text: {
    top: 32,
    left: 85,
    fontSize: FontSize.size_lg,
    lineHeight: 25,
    fontWeight: "500",
    fontFamily: FontFamily.montserratArm,
    color: Color.textColor,
    textAlign: "left",
    position: "absolute",
  },
  shippingCalculatorItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  shippingCalculator: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default ShippingCalculator;
