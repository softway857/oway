import * as React from "react";
import { StyleSheet, View, Pressable, Image, Text } from "react-native";
import Switch1 from "../components/Switch1";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Lucidebell1 from "../assets/lucidebell1.svg";
import Flagforarmeniasvgrepocom from "../assets/flagforarmenia-svgrepocom.svg";
import Lucidelockkeyhole from "../assets/lucidelockkeyhole.svg";
import Lucideuserx from "../assets/lucideuserx.svg";
import Group15 from "../assets/group-15.svg";
import {
  Gap,
  Padding,
  Color,
  FontFamily,
  Border,
  FontSize,
} from "../GlobalStyles";

const Seetings = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.seetings}>
      <View style={styles.seetingsChild} />
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
      <View style={[styles.seetingsItem, styles.seetingsLayout]} />
      <Switch1 checked="on" switchTop={111} switchLeft={303} />
      <View style={[styles.seetingsInner, styles.seetingsLayout]}>
        <Pressable
          style={styles.groupShadowBox}
          onPress={() => navigation.navigate("Laungages")}
        />
      </View>
      <View style={[styles.groupView, styles.seetingsLayout]}>
        <View style={styles.groupShadowBox} />
      </View>
      <View style={[styles.lucidebellParent, styles.parentFlexBox]}>
        <Lucidebell1 style={styles.lucidebellIcon} width={24} height={24} />
        <Text style={[styles.text, styles.textTypo]}>Ծանուցումներ</Text>
      </View>
      <View
        style={[styles.flagForArmeniaSvgrepocomParent, styles.parentFlexBox]}
      >
        <Flagforarmeniasvgrepocom
          style={styles.lucidebellIcon}
          width={24}
          height={24}
        />
        <Text style={[styles.text, styles.textTypo]}>Լեզու</Text>
      </View>
      <Pressable
        style={[styles.lucidelockKeyholeParent, styles.parentFlexBox]}
        onPress={() => navigation.navigate("ChangePass")}
      >
        <Lucidelockkeyhole
          style={styles.lucidebellIcon}
          width={24}
          height={24}
        />
        <Text style={[styles.text, styles.textTypo]}>Փոխել գաղտնաբառը</Text>
      </Pressable>
      <View style={[styles.rectangleParent, styles.seetingsLayout]}>
        <View style={styles.groupShadowBox} />
        <Pressable
          style={[styles.lucideuserXParent, styles.parentFlexBox]}
          onPress={() => navigation.navigate("DeleteAccount")}
        >
          <Lucideuserx style={styles.lucidebellIcon} width={24} height={24} />
          <Text style={[styles.text, styles.textTypo]}>Ջնջել հաշիվը</Text>
        </Pressable>
      </View>
      <Text style={[styles.text4, styles.textTypo]}>Կարգավորումներ</Text>
      <Group15 style={styles.groupIcon} width={40} height={40} />
    </View>
  );
};

const styles = StyleSheet.create({
  seetingsLayout: {
    height: 61,
    width: 333,
    left: 30,
    position: "absolute",
  },
  parentFlexBox: {
    gap: Gap.gap_md,
    padding: Padding.p_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    position: "absolute",
  },
  textTypo: {
    textAlign: "left",
    color: Color.textColor,
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
  },
  seetingsChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    backgroundColor: Color.color2,
    width: 426,
    height: 158,
    position: "absolute",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  seetingsItem: {
    top: 92,
    backgroundColor: Color.themeBackground,
    borderRadius: Border.br_8xs,
    shadowOpacity: 1,
    elevation: 3,
    shadowRadius: 3,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(143, 143, 143, 0.25)",
    width: 333,
  },
  groupShadowBox: {
    left: 0,
    top: 0,
    height: 61,
    width: 333,
    backgroundColor: Color.themeBackground,
    borderRadius: Border.br_8xs,
    shadowOpacity: 1,
    elevation: 3,
    shadowRadius: 3,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(143, 143, 143, 0.25)",
    position: "absolute",
  },
  seetingsInner: {
    top: 158,
  },
  groupView: {
    top: 224,
  },
  lucidebellIcon: {
    overflow: "hidden",
  },
  text: {
    fontSize: FontSize.size_base,
  },
  lucidebellParent: {
    top: 105,
    left: 50,
    padding: Padding.p_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  flagForArmeniaSvgrepocomParent: {
    top: 171,
    left: 50,
    padding: Padding.p_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  lucidelockKeyholeParent: {
    top: 237,
    left: 50,
    padding: Padding.p_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  lucideuserXParent: {
    top: 13,
    left: 20,
  },
  rectangleParent: {
    top: 290,
  },
  text4: {
    top: 32,
    left: 86,
    fontSize: FontSize.size_lg,
    fontWeight: "500",
    position: "absolute",
  },
  groupIcon: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  seetings: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default Seetings;
