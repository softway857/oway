import * as React from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import Group151 from "../assets/group-151.svg";
import InputFields from "../components/InputFields";
import PrimaryButton from "../components/PrimaryButton";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const ForgotPassword = () => {
  return (
    <View style={styles.forgotPassword}>
      <View
        style={[styles.forgotPasswordChild, styles.iphoneIndicatorLayout]}
      />
      <Group151 style={styles.forgotPasswordItem} width={40} height={40} />
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={242}
        inputFieldsLeft={30}
        inputFieldsMarginLeft="unset"
        inputFieldsWidth={333}
        placeholder1="Էլ․ հասցե"
        showPlaceholder
        placeholder2="Էլ․ հասցե"
        placeholderFontWeight="unset"
      />
      <PrimaryButton
        color="Cyan"
        size="default"
        state="Default"
        primaryButtonTop={386}
        primaryButtonLeft={30}
        button="Վերականգնել"
      />
      <Text style={[styles.text, styles.textPosition]}>
        Մոռացե ՞լ եք գաղտնաբառը
      </Text>
      <View style={[styles.iphoneIndicator, styles.iphoneIndicatorLayout]}>
        <View style={[styles.line, styles.textPosition]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  iphoneIndicatorLayout: {
    width: 393,
    position: "absolute",
  },
  textPosition: {
    left: "50%",
    position: "absolute",
  },
  forgotPasswordChild: {
    top: 0,
    left: 0,
    backgroundColor: Color.color2,
    height: 152,
  },
  forgotPasswordItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  text: {
    marginLeft: -152.5,
    top: 188,
    fontSize: FontSize.size_xl,
    fontWeight: "500",
    fontFamily: FontFamily.montserratArm,
    color: Color.colorBlack,
    textAlign: "center",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    height: 30,
  },
  forgotPassword: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default ForgotPassword;
