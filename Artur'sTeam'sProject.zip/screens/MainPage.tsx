import * as React from "react";
import { StyleSheet, View, Image, Text, Pressable } from "react-native";
import Lucideuserround1 from "../assets/lucideuserround1.svg";
import MenuList2 from "../components/MenuList2";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Lucidepackage from "../assets/lucidepackage.svg";
import Lucidemappinned from "../assets/lucidemappinned.svg";
import Lucidehearthandshake from "../assets/lucidehearthandshake.svg";
import Lucidebell from "../assets/lucidebell.svg";
import Ellipse2 from "../assets/ellipse-2.svg";
import {
  Gap,
  Padding,
  Color,
  Border,
  FontSize,
  FontFamily,
} from "../GlobalStyles";

const MainPage = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.mainPage, styles.iconLayout]}>
      <View style={styles.mainPageChild} />
      <Lucideuserround1
        style={styles.lucideuserRoundIcon}
        width={24}
        height={24}
      />
      <MenuList2 />
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
      <Text style={styles.text}>Անուն Ազգանուն</Text>
      <View style={[styles.mainPageItem, styles.mainLayout]} />
      <Pressable
        style={[styles.mainPageInner, styles.mainLayout]}
        onPress={() => navigation.navigate("Addrees")}
      />
      <Pressable
        style={[styles.lucidepackageParent, styles.parentFlexBox]}
        onPress={() => navigation.navigate("Orders")}
      >
        <Lucidepackage
          style={[styles.lucidepackageIcon, styles.lucidebellLayout]}
          width={32}
          height={32}
        />
        <Text style={[styles.text1, styles.textFlexBox]}>Պատվերներ</Text>
      </Pressable>
      <View style={[styles.lucidemapPinnedParent, styles.parentFlexBox]}>
        <Lucidemappinned
          style={[styles.lucidepackageIcon, styles.lucidebellLayout]}
          width={32}
          height={32}
        />
        <Text style={[styles.text1, styles.textFlexBox]}>Հասցեներ</Text>
      </View>
      <Pressable
        style={[styles.rectangleParent, styles.mainLayout]}
        onPress={() => navigation.navigate("Store")}
      >
        <View style={[styles.groupChild, styles.groupChildPosition]} />
        <View style={[styles.lucideheartHandshakeParent, styles.parentFlexBox]}>
          <Lucidehearthandshake
            style={[styles.lucidepackageIcon, styles.lucidebellLayout]}
            width={32}
            height={32}
          />
          <Text style={[styles.text1, styles.textFlexBox]}>Խանութներ</Text>
        </View>
      </Pressable>
      <View style={[styles.groupView, styles.groupViewLayout]}>
        <View style={[styles.lucidebellParent, styles.groupViewLayout]}>
          <Lucidebell
            style={[styles.lucidebell, styles.lucidebellLayout]}
            width={32}
            height={32}
          >
            <Image
              style={[styles.icon, styles.iconLayout]}
              resizeMode="cover"
              source={require("../assets/lucidebell.svg")}
            />
          </Lucidebell>
          <View style={[styles.ellipseParent, styles.groupItemLayout]}>
            <Ellipse2
              style={[styles.groupItem, styles.groupItemLayout]}
              width={16}
              height={16}
            />
            <Text style={[styles.text4, styles.textFlexBox]}>2</Text>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    width: "100%",
    overflow: "hidden",
  },
  mainLayout: {
    height: 80,
    width: 333,
    position: "absolute",
  },
  parentFlexBox: {
    gap: Gap.gap_md,
    padding: Padding.p_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    position: "absolute",
  },
  lucidebellLayout: {
    height: 32,
    width: 32,
  },
  textFlexBox: {
    textAlign: "left",
    color: Color.textColor,
  },
  groupChildPosition: {
    top: 0,
    left: 0,
  },
  groupViewLayout: {
    height: 38,
    width: 36,
    position: "absolute",
  },
  groupItemLayout: {
    height: 16,
    width: 16,
    top: 0,
    position: "absolute",
  },
  mainPageChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    backgroundColor: Color.color2,
    width: 426,
    height: 158,
    position: "absolute",
  },
  lucideuserRoundIcon: {
    top: 35,
    left: 103,
    position: "absolute",
    overflow: "hidden",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    left: "50%",
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    backgroundColor: Color.themeBackground,
    position: "absolute",
  },
  text: {
    marginLeft: -59.5,
    top: 37,
    fontSize: FontSize.size_base,
    fontWeight: "500",
    textAlign: "center",
    color: Color.textColor,
    fontFamily: FontFamily.montserratArm,
    left: "50%",
    position: "absolute",
  },
  mainPageItem: {
    top: 92,
    borderRadius: Border.br_8xs,
    shadowOpacity: 1,
    elevation: 3,
    shadowRadius: 3,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(143, 143, 143, 0.25)",
    width: 333,
    backgroundColor: Color.themeBackground,
    left: 30,
  },
  mainPageInner: {
    top: 192,
    borderRadius: Border.br_8xs,
    shadowOpacity: 1,
    elevation: 3,
    shadowRadius: 3,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(143, 143, 143, 0.25)",
    width: 333,
    backgroundColor: Color.themeBackground,
    left: 30,
  },
  lucidepackageIcon: {
    overflow: "hidden",
  },
  text1: {
    fontSize: FontSize.size_lg,
    lineHeight: 25,
    fontFamily: FontFamily.montserratArm,
    textAlign: "left",
  },
  lucidepackageParent: {
    top: 111,
    left: 50,
    gap: Gap.gap_md,
    padding: Padding.p_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  lucidemapPinnedParent: {
    top: 211,
    left: 50,
    gap: Gap.gap_md,
    padding: Padding.p_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  groupChild: {
    left: 0,
    height: 80,
    width: 333,
    position: "absolute",
    borderRadius: Border.br_8xs,
    shadowOpacity: 1,
    elevation: 3,
    shadowRadius: 3,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(143, 143, 143, 0.25)",
    backgroundColor: Color.themeBackground,
  },
  lucideheartHandshakeParent: {
    top: 19,
    left: 20,
  },
  rectangleParent: {
    top: 292,
    left: 30,
  },
  icon: {
    height: "100%",
    overflow: "hidden",
  },
  lucidebell: {
    top: 6,
    left: 0,
    position: "absolute",
  },
  groupItem: {
    left: 0,
  },
  text4: {
    top: "6.25%",
    left: "31.25%",
    fontSize: FontSize.size_xs,
    fontWeight: "700",
    fontFamily: FontFamily.arial,
    position: "absolute",
  },
  ellipseParent: {
    left: 20,
  },
  lucidebellParent: {
    left: 0,
    top: 0,
  },
  groupView: {
    top: 13,
    left: 334,
  },
  mainPage: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    height: 907,
    overflow: "hidden",
  },
});

export default MainPage;
