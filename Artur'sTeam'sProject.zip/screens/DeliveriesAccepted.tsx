import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Group15 from "../assets/group-15.svg";
import GroupComponent3 from "../components/GroupComponent3";
import { FontFamily, Border, Color, FontSize } from "../GlobalStyles";

const DeliveriesAccepted = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.deliveriesAccepted}>
      <View style={styles.deliveriesAcceptedChild} />
      <Text style={[styles.text, styles.textTypo]}>Ընդունված առաքանիներ</Text>
      <Group15 style={styles.deliveriesAcceptedItem} width={40} height={40} />
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
      <GroupComponent3
        onGroupPressablePress={() => navigation.navigate("DeliveriesAccepted1")}
        prop="0,2կգ"
        prop1="Չինաստան"
        chinassvgFill={require("../assets/chinassvg-fill1.png")}
        prop2="1000դր"
      />
      <GroupComponent3
        onGroupPressablePress={() => navigation.navigate("DeliveriesAccepted1")}
        groupPressableTop={472}
        prop="0,2կգ"
        prop1="Չինաստան"
        chinassvgFill={require("../assets/chinassvg-fill1.png")}
        prop2="1000դր"
        textLeft={9}
      />
      <GroupComponent3
        onGroupPressablePress={() => navigation.navigate("DeliveriesAccepted1")}
        groupPressableTop={187}
        prop="0,1կգ"
        prop1="Իսպանիա"
        chinassvgFill={require("../assets/chinassvg-fill2.png")}
        prop2="480դր"
        textLeft={12}
      />
      <GroupComponent3
        onGroupPressablePress={() => navigation.navigate("DeliveriesAccepted1")}
        groupPressableTop={567}
        prop="0,1կգ"
        prop1="Իսպանիա"
        chinassvgFill={require("../assets/chinassvg-fill2.png")}
        prop2="480դր"
        textLeft={12}
      />
      <GroupComponent3
        onGroupPressablePress={() => navigation.navigate("DeliveriesAccepted1")}
        groupPressableTop={282}
        prop="0,3կգ"
        prop1="Իսպանիա"
        chinassvgFill={require("../assets/chinassvg-fill2.png")}
        prop2="1440դր"
        textLeft={9}
      />
      <GroupComponent3
        onGroupPressablePress={() => navigation.navigate("DeliveriesAccepted1")}
        groupPressableTop={662}
        prop="0,3կգ"
        prop1="Իսպանիա"
        chinassvgFill={require("../assets/chinassvg-fill2.png")}
        prop2="1440դր"
        textLeft={9}
      />
      <GroupComponent3
        onGroupPressablePress={() => navigation.navigate("DeliveriesAccepted1")}
        groupPressableTop={377}
        prop="0,4կգ"
        prop1="Չինաստան"
        chinassvgFill={require("../assets/chinassvg-fill1.png")}
        prop2="2000դր"
        textLeft={9}
      />
      <GroupComponent3
        onGroupPressablePress={() => navigation.navigate("DeliveriesAccepted1")}
        groupPressableTop={757}
        prop="0,4կգ"
        prop1="Չինաստան"
        chinassvgFill={require("../assets/chinassvg-fill1.png")}
        prop2="2000դր"
        textLeft={9}
      />
      <View style={styles.deliveriesAcceptedInner}>
        <View style={styles.groupChildPosition}>
          <View style={[styles.groupChild, styles.groupChildPosition]} />
          <Text style={[styles.text1, styles.textTypo]}>Ընդհանուր 23</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  textTypo: {
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    fontWeight: "500",
    lineHeight: 25,
    position: "absolute",
  },
  groupChildPosition: {
    left: 0,
    top: 0,
    height: 39,
    width: 207,
    position: "absolute",
  },
  deliveriesAcceptedChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    backgroundColor: Color.color2,
    width: 426,
    height: 158,
    position: "absolute",
  },
  text: {
    top: 32,
    left: 85,
    fontSize: FontSize.size_lg,
    color: Color.textColor,
  },
  deliveriesAcceptedItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  groupChild: {
    borderRadius: 10,
    backgroundColor: Color.textColor,
  },
  text1: {
    top: 7,
    left: 42,
    fontSize: FontSize.size_base,
    color: Color.bgColor,
  },
  deliveriesAcceptedInner: {
    top: 834,
    left: 93,
    height: 39,
    width: 207,
    position: "absolute",
  },
  deliveriesAccepted: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default DeliveriesAccepted;
