import * as React from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import IsolationMode from "../components/IsolationMode";
import Group151 from "../assets/group-151.svg";
import InputFields from "../components/InputFields";
import Group12525 from "../assets/group-12525.svg";
import Vector36 from "../assets/vector-36.svg";
import Chevrondown from "../assets/chevrondown.svg";
import PrimaryButton from "../components/PrimaryButton";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const Registration = () => {
  return (
    <View style={styles.registration}>
      <View style={[styles.registrationChild, styles.iphoneIndicatorLayout]} />
      <Image
        style={[styles.tom1Icon, styles.tom1IconPosition]}
        resizeMode="cover"
        source={require("../assets/tom-1.png")}
      />
      <IsolationMode />
      <Group151
        style={[styles.registrationItem, styles.tom1IconPosition]}
        width={40}
        height={40}
      />
      <Text style={[styles.text, styles.textPosition]}>Գրանցում</Text>
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={242}
        inputFieldsLeft={30}
        inputFieldsMarginLeft="unset"
        inputFieldsWidth={333}
        placeholder1="Էլ․ հասցե"
        showPlaceholder
        placeholder2="Էլ․ հասցե"
        placeholderFontWeight="unset"
      />
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={336}
        inputFieldsLeft={30}
        inputFieldsMarginLeft="unset"
        inputFieldsWidth={333}
        placeholder1="Հեռախոսահամար"
        showPlaceholder
        placeholder2="       +374"
        placeholderFontWeight="unset"
      />
      <Image
        style={styles.registrationInner}
        resizeMode="cover"
        source={require("../assets/group-795.png")}
      />
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={430}
        inputFieldsLeft={30}
        inputFieldsMarginLeft="unset"
        inputFieldsWidth={333}
        placeholder1="Գաղտնաբառ"
        showPlaceholder
        placeholder2="Գաղտնաբառ"
        placeholderFontWeight="unset"
      />
      <Group12525
        style={[styles.groupIcon, styles.groupIconLayout]}
        width={18}
        height={18}
      />
      <Group12525
        style={[styles.registrationChild1, styles.registrationChildPosition]}
        width={18}
        height={18}
      />
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={524}
        inputFieldsLeft={30}
        inputFieldsMarginLeft="unset"
        inputFieldsWidth={333}
        placeholder1="Կրկնել գաղտնաբառը"
        showPlaceholder
        placeholder2="Կրկնել գաղտնաբառը"
        placeholderFontWeight="unset"
      />
      <Group12525
        style={[styles.registrationChild2, styles.groupIconLayout]}
        width={18}
        height={18}
      />
      <Vector36 style={styles.vectorIcon} height={50} />
      <Group12525
        style={[styles.registrationChild3, styles.registrationChildPosition]}
        width={18}
        height={18}
      />
      <Chevrondown style={styles.chevronDownIcon} width={12} height={12} />
      <PrimaryButton
        color="Orange"
        size="default"
        state="Default"
        primaryButtonTop={628}
        primaryButtonLeft={30}
        button="Գրանցվել"
      />
      <View style={[styles.iphoneIndicator, styles.iphoneIndicatorLayout]}>
        <View style={[styles.line, styles.textPosition]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  iphoneIndicatorLayout: {
    width: 393,
    position: "absolute",
  },
  tom1IconPosition: {
    top: 24,
    position: "absolute",
  },
  textPosition: {
    left: "50%",
    position: "absolute",
  },
  groupIconLayout: {
    height: 18,
    width: 18,
    left: 333,
    position: "absolute",
  },
  registrationChildPosition: {
    left: 449,
    height: 18,
    width: 18,
    position: "absolute",
  },
  registrationChild: {
    top: 0,
    left: 0,
    backgroundColor: Color.color1,
    height: 152,
  },
  tom1Icon: {
    left: 67,
    width: 168,
    height: 168,
  },
  registrationItem: {
    left: 30,
  },
  text: {
    marginLeft: -55.5,
    top: 188,
    fontSize: FontSize.size_xl,
    fontWeight: "500",
    fontFamily: FontFamily.montserratArm,
    color: Color.colorBlack,
    textAlign: "center",
  },
  registrationInner: {
    top: 378,
    left: 46,
    width: 24,
    height: 14,
    position: "absolute",
  },
  groupIcon: {
    top: 470,
  },
  registrationChild1: {
    top: 396,
  },
  registrationChild2: {
    top: 564,
  },
  vectorIcon: {
    top: 360,
    left: 128,
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  registrationChild3: {
    top: 492,
  },
  chevronDownIcon: {
    top: 379,
    left: 109,
    position: "absolute",
    overflow: "hidden",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    height: 30,
  },
  registration: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default Registration;
