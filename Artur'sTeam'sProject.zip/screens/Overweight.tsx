import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import Group15 from "../assets/group-15.svg";
import InputFields from "../components/InputFields";
import Path from "../assets/path.svg";
import GroupComponent from "../components/GroupComponent";
import { Color, FontFamily, Border, FontSize, Gap } from "../GlobalStyles";

const Overweight = () => {
  return (
    <View style={styles.overweight}>
      <View style={styles.overweightChild} />
      <Text style={[styles.text, styles.textTypo]}>Հաշվիչ</Text>
      <Group15 style={styles.overweightItem} width={40} height={40} />
      <View style={[styles.overweightInner, styles.groupItemTransform]} />
      <View style={styles.iphoneIndicator}>
        <View style={[styles.line, styles.linePosition]} />
      </View>
      <InputFields
        placeholder
        state="Default"
        placeholder1="Քաշ (կգ)"
        showPlaceholder
        placeholder2="Քաշ (կգ)"
      />
      <View style={styles.inputFieldsParent}>
        <InputFields
          placeholder
          state="Default"
          inputFieldsTop={228}
          inputFieldsLeft={0}
          inputFieldsMarginLeft="unset"
          inputFieldsWidth={333}
          placeholder1="Երկարություն
"
          showPlaceholder
          placeholder2="Երկարություն
"
          placeholderFontWeight="unset"
        />
        <InputFields
          placeholder
          state="Default"
          inputFieldsTop={317}
          inputFieldsLeft={0}
          inputFieldsMarginLeft="unset"
          inputFieldsWidth={333}
          placeholder1="Լայնություն"
          showPlaceholder
          placeholder2="Լայնություն"
          placeholderFontWeight="unset"
        />
        <InputFields
          placeholder
          state="Default"
          inputFieldsTop={406}
          inputFieldsLeft={0}
          inputFieldsMarginLeft="unset"
          inputFieldsWidth={333}
          placeholder1="Բարձրություն"
          showPlaceholder
          placeholder2="Բարձրություն"
          placeholderFontWeight="unset"
        />
        <Text style={[styles.text1, styles.linePosition]}>
          Գերծավալային քաշ
        </Text>
        <View style={[styles.frame, styles.framePosition]} />
        <Path style={styles.pathIcon} width={4} height={1} />
        <GroupComponent />
        <Text style={styles.xX}>
          Բեռը համարվում է գերծավալային քաշով, եթե կողմերի երկարությունների
          գումարը գերազանցում է 150 սմ-ը և ծավալային** քաշը 2 և ավելի անգամ
          գերազանցում է փաստացի քաշը: Այս դեպքում հաշվարկվում է ըստ բեռի
          ծավալային քաշի, սակայն գործում է հատուկ զեղչված սակագին՝ 5000 դր/կգ **
          Ծավալային քաշի հաշվարկի միջազգային բանաձևն է՝ (Երկարություն X
          Լայնություն X Բարձրություն) / 5000 (սմ/կգ)
        </Text>
      </View>
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <View style={styles.flagUsasvgParent}>
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/russiasvg.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg1.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg2.png")}
          />
          <Image
            style={styles.flagUsasvgIcon}
            resizeMode="cover"
            source={require("../assets/flagusasvg3.png")}
          />
        </View>
        <View style={[styles.groupItem, styles.groupItemTransform]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  textTypo: {
    textAlign: "left",
    color: Color.textColor,
    fontFamily: FontFamily.montserratArm,
  },
  groupItemTransform: {
    transform: [
      {
        rotate: "-90deg",
      },
    ],
    width: 2,
    backgroundColor: Color.color2,
    position: "absolute",
  },
  linePosition: {
    left: "50%",
    position: "absolute",
  },
  framePosition: {
    shadowOpacity: 1,
    top: 0,
    left: 0,
  },
  groupChildLayout: {
    height: 70,
    width: 333,
    position: "absolute",
  },
  overweightChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    width: 426,
    height: 158,
    backgroundColor: Color.color2,
    position: "absolute",
  },
  text: {
    top: 32,
    left: 85,
    fontSize: FontSize.size_lg,
    lineHeight: 25,
    fontWeight: "500",
    position: "absolute",
  },
  overweightItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  overweightInner: {
    top: 142,
    left: 43,
    height: 41,
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  text1: {
    marginLeft: -136.5,
    top: 4,
    fontSize: FontSize.size_sm,
    textAlign: "left",
    color: Color.textColor,
    fontFamily: FontFamily.montserratArm,
  },
  frame: {
    shadowColor: "rgba(0, 0, 0, 0.07)",
    shadowOffset: {
      width: 0,
      height: 7,
    },
    shadowRadius: 64,
    elevation: 64,
    borderRadius: Border.br_9xs,
    borderStyle: "solid",
    borderColor: Color.strokeColor,
    borderWidth: 1,
    width: 24,
    height: 24,
    position: "absolute",
  },
  pathIcon: {
    top: "1.44%",
    right: "94.59%",
    bottom: "97.12%",
    left: "1.8%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  xX: {
    top: 31,
    fontSize: FontSize.size_xs,
    lineHeight: 18,
    color: "#676767",
    left: 0,
    width: 333,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    position: "absolute",
  },
  inputFieldsParent: {
    top: 263,
    height: 555,
    width: 333,
    left: 30,
    position: "absolute",
  },
  groupChild: {
    shadowColor: "rgba(0, 0, 0, 0.05)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 2,
    elevation: 2,
    borderRadius: Border.br_6xs,
    backgroundColor: Color.themeBackground,
    shadowOpacity: 1,
    top: 0,
    left: 0,
  },
  flagUsasvgIcon: {
    width: 45,
    height: 27,
    overflow: "hidden",
  },
  flagUsasvgParent: {
    top: 22,
    left: 17,
    flexDirection: "row",
    alignItems: "center",
    gap: Gap.gap_xl,
    position: "absolute",
  },
  groupItem: {
    top: 56,
    left: 13,
    height: 54,
  },
  rectangleParent: {
    top: 88,
    left: 30,
  },
  overweight: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default Overweight;
