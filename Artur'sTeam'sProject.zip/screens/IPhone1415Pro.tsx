import * as React from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import PrimaryButton from "../components/PrimaryButton";
import Group1 from "../assets/group-1.svg";
import Flagforarmeniasvgrepocom2 from "../assets/flagforarmenia-svgrepocom2.svg";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const IPhone1415Pro = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.iphone1415Pro21}>
      <Image
        style={[styles.untitled1Icon, styles.linePosition]}
        resizeMode="cover"
        source={require("../assets/untitled1.png")}
      />
      <PrimaryButton
        color="Cyan"
        size="default"
        state="Default"
        primaryButtonTop={678}
        primaryButtonLeft={30}
        onPrimaryButtonPress={() => navigation.navigate("Login")}
        button="Մուտք"
      />
      <PrimaryButton
        color="Orange"
        size="default"
        state="Default"
        primaryButtonTop={758}
        primaryButtonLeft={30}
        onPrimaryButtonPress={() => navigation.navigate("Registration")}
        button="Գրանցվել"
      />
      <View style={styles.groupParent}>
        <View style={styles.groupContainer}>
          <Group1
            style={[styles.groupChild, styles.textPosition]}
            width={35}
            height={100}
          />
          <Text style={[styles.text, styles.textPosition]}>Հայ</Text>
        </View>
        <Flagforarmeniasvgrepocom2
          style={[styles.flagForArmeniaSvgrepocomIcon, styles.withBox1Position]}
          width={24}
          height={24}
        />
      </View>
      <Image
        style={[styles.withBox1, styles.withBox1Position]}
        resizeMode="cover"
        source={require("../assets/with-box-1.png")}
      />
      <View style={styles.iphoneIndicator}>
        <View style={[styles.line, styles.linePosition]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  linePosition: {
    left: "50%",
    position: "absolute",
  },
  textPosition: {
    top: "0%",
    position: "absolute",
  },
  withBox1Position: {
    left: 0,
    position: "absolute",
  },
  untitled1Icon: {
    marginLeft: -166.5,
    top: 93,
    width: 333,
    height: 172,
  },
  groupChild: {
    bottom: "0%",
    left: "64.91%",
    maxWidth: "100%",
    maxHeight: "100%",
    right: "0%",
    overflow: "hidden",
  },
  text: {
    left: "0%",
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.montserratArm,
    color: Color.textColor,
    textAlign: "left",
  },
  groupContainer: {
    height: "83.33%",
    width: "65.52%",
    top: "8.33%",
    bottom: "8.33%",
    left: "34.48%",
    right: "0%",
    position: "absolute",
  },
  flagForArmeniaSvgrepocomIcon: {
    top: 0,
    overflow: "hidden",
  },
  groupParent: {
    height: "2.65%",
    width: "22.14%",
    top: "4.41%",
    right: "70.23%",
    bottom: "92.94%",
    left: "7.63%",
    position: "absolute",
  },
  withBox1: {
    top: 270,
    width: 400,
    height: 386,
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
    backgroundColor: Color.bgColor,
  },
  iphone1415Pro21: {
    borderRadius: Border.br_21xl,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
    backgroundColor: Color.bgColor,
  },
});

export default IPhone1415Pro;
