import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import Group15 from "../assets/group-15.svg";
import GroupComponent11 from "../components/GroupComponent11";
import Lucideclock7 from "../assets/lucideclock7.svg";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const ContactUs = () => {
  return (
    <View style={styles.contactUs}>
      <View style={styles.contactUsChild} />
      <Text style={styles.text}> Կապ մեզ հետ</Text>
      <Group15
        style={[styles.contactUsItem, styles.contactPosition]}
        width={40}
        height={40}
      />
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
      <View style={[styles.contactUsInner, styles.contactPosition]} />
      <GroupComponent11 />
      <Image
        style={[styles.iconsEmail, styles.iconsLayout]}
        resizeMode="cover"
        source={require("../assets/icons--email.png")}
      />
      <Lucideclock7 style={styles.lucideclock7Icon} width={24} height={24} />
      <Image
        style={[styles.iconsPin, styles.iconsLayout]}
        resizeMode="cover"
        source={require("../assets/icons--pin.png")}
      />
      <Text style={[styles.text1, styles.textTypo1]}>Հասցե</Text>
      <Text style={[styles.text2, styles.textTypo1]}>Հեռախոսահամար</Text>
      <Text style={[styles.text3, styles.textTypo1]}>Սպասարկման կենտրոն</Text>
      <View style={styles.parent}>
        <Text style={[styles.text4, styles.textTypo]}>
          ք․Երևան, Բաշինջաղյան 198
        </Text>
        <Text style={[styles.text5, styles.textTypo]}>+374 33 79 88 88</Text>
        <Text style={[styles.text6, styles.textTypo]}>
          Երկ-Ուրբ - 10։30-19։00
        </Text>
        <Text style={[styles.text7, styles.textTypo]}>+374 60 77 10 10</Text>
      </View>
      <Image
        style={[styles.iconsPhonePhone, styles.iconsLayout]}
        resizeMode="cover"
        source={require("../assets/icons--phone--phone.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  contactPosition: {
    left: 30,
    position: "absolute",
  },
  iconsLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    left: "12.47%",
    right: "81.42%",
    width: "6.11%",
    height: "2.65%",
    position: "absolute",
    overflow: "hidden",
  },
  textTypo1: {
    color: Color.colorGray_100,
    fontSize: FontSize.size_sm,
    left: 78,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    position: "absolute",
  },
  textTypo: {
    left: "0%",
    fontSize: FontSize.size_sm,
    textAlign: "left",
    color: Color.textColor,
    fontFamily: FontFamily.montserratArm,
    fontWeight: "500",
    position: "absolute",
  },
  contactUsChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    backgroundColor: Color.color2,
    width: 426,
    height: 158,
    position: "absolute",
  },
  text: {
    top: 32,
    left: 85,
    fontSize: FontSize.size_lg,
    lineHeight: 25,
    textAlign: "left",
    color: Color.textColor,
    fontFamily: FontFamily.montserratArm,
    fontWeight: "500",
    position: "absolute",
  },
  contactUsItem: {
    top: 24,
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  contactUsInner: {
    top: 105,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    borderRadius: Border.br_6xs,
    backgroundColor: Color.themeBackground,
    width: 333,
    height: 285,
  },
  iconsEmail: {
    top: "46.75%",
    bottom: "50.61%",
  },
  lucideclock7Icon: {
    top: 295,
    left: 49,
    position: "absolute",
    overflow: "hidden",
  },
  iconsPin: {
    top: "14.11%",
    bottom: "83.24%",
  },
  text1: {
    top: 131,
  },
  text2: {
    top: 201,
  },
  text3: {
    top: 298,
  },
  text4: {
    top: "0%",
  },
  text5: {
    top: "38.04%",
  },
  text6: {
    top: "90.76%",
  },
  text7: {
    top: "52.72%",
  },
  parent: {
    height: "20.29%",
    width: "55.73%",
    top: "17.2%",
    right: "24.43%",
    bottom: "62.51%",
    left: "19.85%",
    position: "absolute",
  },
  iconsPhonePhone: {
    top: "21.83%",
    bottom: "75.52%",
  },
  contactUs: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default ContactUs;
