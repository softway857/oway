import * as React from "react";
import { StyleSheet, View, Image, Text, Pressable } from "react-native";
import Lucidebell from "../assets/lucidebell.svg";
import MenuList3 from "../components/MenuList3";
import InputFields from "../components/InputFields";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import Attentionsvgrepocom from "../assets/attention-svgrepocom.svg";
import PrimaryButton from "../components/PrimaryButton";
import { Color, Border, FontSize, FontFamily, Gap } from "../GlobalStyles";

const AddOrder1 = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={[styles.addOrder, styles.iconLayout]}>
      <View style={[styles.addOrderChild, styles.groupItemBg]} />
      <Lucidebell style={styles.lucidebellIcon} width={32} height={32} />
      <MenuList3 />
      <View style={styles.iphoneIndicator}>
        <View style={[styles.line, styles.linePosition]} />
      </View>
      <Text style={[styles.text, styles.linePosition]}>Ավելացնել պատվեր</Text>
      <View style={styles.inputFieldsParent}>
        <InputFields
          placeholder
          state="Default"
          inputFieldsTop={85}
          inputFieldsLeft={0}
          inputFieldsMarginLeft="unset"
          inputFieldsWidth={333}
          placeholder1="Tracking համար"
          showPlaceholder
          placeholder2="Tracking համար"
          placeholderFontWeight="unset"
        />
        <InputFields
          placeholder
          state="Default"
          inputFieldsTop={179}
          inputFieldsLeft={0}
          inputFieldsMarginLeft="unset"
          inputFieldsWidth={333}
          placeholder1="Անուն"
          showPlaceholder
          placeholder2="Անուն"
          placeholderFontWeight="unset"
        />
        <InputFields
          placeholder
          state="Default"
          inputFieldsTop={273}
          inputFieldsLeft={0}
          inputFieldsMarginLeft="unset"
          inputFieldsWidth={215}
          placeholder1="Արժեք"
          showPlaceholder
          placeholder2="Արժեք"
          placeholderFontWeight="unset"
        />
        <Attentionsvgrepocom
          style={styles.attentionSvgrepocom}
          width={16}
          height={16}
        >
          <Image
            style={[styles.icon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/attention-svgrepocom.svg")}
          />
        </Attentionsvgrepocom>
        <PrimaryButton
          color="Cyan"
          size="default"
          state="Default"
          primaryButtonTop={514}
          button="Ավելացնել"
        />
        <View style={styles.groupChildPosition}>
          <View style={[styles.groupChild, styles.groupChildPosition]} />
          <View style={styles.flagUsasvgParent}>
            <Image
              style={styles.flagUsasvgIcon}
              resizeMode="cover"
              source={require("../assets/flagusasvg4.png")}
            />
            <Image
              style={styles.flagUsasvgIcon}
              resizeMode="cover"
              source={require("../assets/russiasvg.png")}
            />
            <Image
              style={styles.flagUsasvgIcon}
              resizeMode="cover"
              source={require("../assets/flagusasvg1.png")}
            />
            <Image
              style={styles.flagUsasvgIcon}
              resizeMode="cover"
              source={require("../assets/flagusasvg2.png")}
            />
            <Image
              style={styles.flagUsasvgIcon}
              resizeMode="cover"
              source={require("../assets/flagusasvg3.png")}
            />
          </View>
          <View style={[styles.groupItem, styles.groupItemBg]} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    width: "100%",
    overflow: "hidden",
  },
  groupItemBg: {
    backgroundColor: Color.color2,
    position: "absolute",
  },
  linePosition: {
    left: "50%",
    position: "absolute",
  },
  groupChildPosition: {
    height: 70,
    left: 0,
    top: 0,
    width: 333,
    position: "absolute",
  },
  addOrderChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    width: 426,
    height: 158,
  },
  lucidebellIcon: {
    top: 19,
    left: 334,
    position: "absolute",
    overflow: "hidden",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    backgroundColor: Color.themeBackground,
    position: "absolute",
  },
  text: {
    marginLeft: -88.5,
    top: 37,
    fontSize: FontSize.size_base,
    fontWeight: "500",
    fontFamily: FontFamily.montserratArm,
    color: Color.textColor,
    textAlign: "center",
  },
  icon: {
    height: "100%",
    overflow: "hidden",
  },
  attentionSvgrepocom: {
    left: 57,
    top: 276,
    position: "absolute",
  },
  groupChild: {
    shadowColor: "rgba(0, 0, 0, 0.05)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 2,
    elevation: 2,
    shadowOpacity: 1,
    borderRadius: Border.br_6xs,
    backgroundColor: Color.themeBackground,
  },
  flagUsasvgIcon: {
    width: 45,
    height: 27,
    overflow: "hidden",
  },
  flagUsasvgParent: {
    top: 22,
    left: 17,
    flexDirection: "row",
    alignItems: "center",
    gap: Gap.gap_xl,
    position: "absolute",
  },
  groupItem: {
    top: 56,
    left: 13,
    width: 2,
    height: 54,
    transform: [
      {
        rotate: "-90deg",
      },
    ],
  },
  inputFieldsParent: {
    top: 88,
    left: 30,
    height: 564,
    width: 333,
    position: "absolute",
  },
  addOrder: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    height: 907,
    overflow: "hidden",
  },
});

export default AddOrder1;
