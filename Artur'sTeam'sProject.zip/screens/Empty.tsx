import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import Group15 from "../assets/group-15.svg";
import { FontFamily, Border, Color, FontSize } from "../GlobalStyles";

const Empty = () => {
  return (
    <View style={styles.empty}>
      <View style={styles.emptyChild} />
      <Text style={[styles.text, styles.textTypo]}>Պատվիրված է</Text>
      <Group15 style={styles.emptyItem} width={40} height={40} />
      <View style={[styles.emptyInner, styles.emptyInnerLayout]}>
        <Image
          style={[styles.groupChild, styles.text1Position]}
          resizeMode="cover"
          source={require("../assets/group-48096304.png")}
        />
      </View>
      <View style={[styles.groupView, styles.wrapperLayout]}>
        <View style={[styles.wrapper, styles.wrapperLayout]}>
          <Text style={[styles.text1, styles.text1Position]}>
            Ներկայումս Դուք դեռ չունեք պատվերներ
          </Text>
        </View>
      </View>
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  textTypo: {
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    fontWeight: "500",
    position: "absolute",
  },
  emptyInnerLayout: {
    height: 176,
    width: 176,
    position: "absolute",
  },
  text1Position: {
    left: 0,
    top: 0,
  },
  wrapperLayout: {
    height: 11,
    width: 319,
    position: "absolute",
  },
  emptyChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_60xl,
    backgroundColor: Color.color2,
    width: 426,
    height: 158,
    position: "absolute",
  },
  text: {
    top: 32,
    left: 85,
    fontSize: FontSize.size_lg,
    lineHeight: 25,
    color: Color.textColor,
  },
  emptyItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  groupChild: {
    height: 176,
    width: 176,
    position: "absolute",
  },
  emptyInner: {
    top: 186,
    left: 107,
  },
  text1: {
    fontSize: FontSize.size_sm,
    lineHeight: 11,
    color: Color.colorBlack,
    textAlign: "left",
    fontFamily: FontFamily.montserratArm,
    fontWeight: "500",
    position: "absolute",
  },
  wrapper: {
    left: 0,
    top: 0,
  },
  groupView: {
    top: 356,
    left: 37,
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  empty: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default Empty;
