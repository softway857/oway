import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import MenuList1 from "../components/MenuList1";
import GroupComponent6 from "../components/GroupComponent6";
import Group15 from "../assets/group-15.svg";
import GroupComponent7 from "../components/GroupComponent7";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const Laungages = () => {
  return (
    <View style={styles.laungages}>
      <View style={styles.laungagesChild} />
      <MenuList1 />
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
      <GroupComponent6 />
      <Text style={styles.text}>Կարգավորումներ</Text>
      <Group15 style={styles.laungagesItem} width={40} height={40} />
      <GroupComponent7 />
    </View>
  );
};

const styles = StyleSheet.create({
  laungagesChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    backgroundColor: Color.color2,
    width: 426,
    height: 158,
    position: "absolute",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  text: {
    top: 32,
    left: 86,
    fontSize: FontSize.size_lg,
    lineHeight: 25,
    fontWeight: "500",
    fontFamily: FontFamily.montserratArm,
    color: Color.textColor,
    textAlign: "left",
    position: "absolute",
  },
  laungagesItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  laungages: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default Laungages;
