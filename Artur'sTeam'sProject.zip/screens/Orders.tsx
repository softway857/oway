import * as React from "react";
import { StyleSheet, View, Text, Image, Pressable } from "react-native";
import Group15 from "../assets/group-15.svg";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import BadgeCount from "../components/BadgeCount";
import { Color, FontFamily, Border, Padding, FontSize } from "../GlobalStyles";

const Orders = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.orders}>
      <View style={styles.ordersChild} />
      <Text style={[styles.text, styles.textTypo]}>Պատվերներ</Text>
      <Group15 style={styles.ordersItem} width={40} height={40} />
      <View style={styles.rectangleParent}>
        <Pressable
          style={[styles.groupChild, styles.groupShadowBox]}
          onPress={() => navigation.navigate("Empty")}
        />
        <BadgeCount property1="Filled" size="Small" showBadgeCount label="0" />
        <View style={[styles.groupItem, styles.groupShadowBox]} />
        <BadgeCount
          property1="Filled"
          size="Small"
          showBadgeCount
          badgeCountMarginTop={-114}
          badgeCountPosition="absolute"
          badgeCountMarginLeft={117.5}
          badgeCountTop="50%"
          badgeCountLeft="50%"
          badgeCountBorderRadius={20}
          badgeCountWidth={29}
          badgeCountHeight={29}
          label="2"
        />
        <View style={[styles.groupInner, styles.groupShadowBox]} />
        <Pressable
          style={[styles.rectanglePressable, styles.groupShadowBox]}
          onPress={() => navigation.navigate("InArmenia")}
        />
        <View style={[styles.rectangleView, styles.groupShadowBox]} />
        <View style={[styles.wrapper, styles.frameWrapperFlexBox]}>
          <Text style={[styles.text1, styles.textTypo]}>Ընդունված է</Text>
        </View>
        <View style={[styles.container, styles.frameWrapperFlexBox]}>
          <Text style={[styles.text1, styles.textTypo]}>Պատվիրված է</Text>
        </View>
        <View style={[styles.frame, styles.frameWrapperFlexBox]}>
          <Text style={[styles.text1, styles.textTypo]}>Հասել է պահեստ</Text>
        </View>
        <View style={[styles.frameView, styles.frameWrapperFlexBox]}>
          <Text style={[styles.text1, styles.textTypo]}>Ճանապարհին է</Text>
        </View>
        <View style={[styles.wrapper1, styles.frameWrapperFlexBox]}>
          <Text style={[styles.text1, styles.textTypo]}>Հայաստանում է</Text>
        </View>
        <BadgeCount
          property1="Filled"
          size="Small"
          showBadgeCount
          badgeCountMarginTop={-14}
          badgeCountPosition="absolute"
          badgeCountMarginLeft={117.5}
          badgeCountTop="50%"
          badgeCountLeft="50%"
          badgeCountBorderRadius={20}
          badgeCountWidth={29}
          badgeCountHeight={29}
          label="0"
        />
        <BadgeCount
          property1="Filled"
          size="Small"
          showBadgeCount
          badgeCountMarginTop={86}
          badgeCountPosition="absolute"
          badgeCountMarginLeft={117.5}
          badgeCountTop="50%"
          badgeCountLeft="50%"
          badgeCountBorderRadius={20}
          badgeCountWidth={29}
          badgeCountHeight={29}
          label="4"
        />
        <BadgeCount
          property1="Filled"
          size="Small"
          showBadgeCount
          badgeCountMarginTop={186}
          badgeCountPosition="absolute"
          badgeCountMarginLeft={117.5}
          badgeCountTop="50%"
          badgeCountLeft="50%"
          badgeCountBorderRadius={20}
          badgeCountWidth={29}
          badgeCountHeight={29}
          label="0"
        />
      </View>
      <View style={styles.iphoneIndicator}>
        <View style={styles.line} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  textTypo: {
    textAlign: "left",
    color: Color.textColor,
    fontFamily: FontFamily.montserratArm,
    lineHeight: 25,
  },
  groupShadowBox: {
    height: 80,
    backgroundColor: Color.themeBackground,
    borderRadius: Border.br_8xs,
    shadowOpacity: 1,
    elevation: 3,
    shadowRadius: 3,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(143, 143, 143, 0.25)",
    left: 0,
    width: 333,
    position: "absolute",
  },
  frameWrapperFlexBox: {
    padding: Padding.p_8xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    left: 20,
    position: "absolute",
  },
  ordersChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    backgroundColor: Color.color2,
    width: 426,
    height: 158,
    position: "absolute",
  },
  text: {
    top: 32,
    left: 85,
    fontSize: FontSize.size_lg,
    fontWeight: "500",
    position: "absolute",
  },
  ordersItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  groupChild: {
    top: 0,
  },
  groupItem: {
    top: 100,
  },
  groupInner: {
    top: 200,
  },
  rectanglePressable: {
    top: 300,
  },
  rectangleView: {
    top: 400,
  },
  text1: {
    fontSize: FontSize.size_base,
  },
  wrapper: {
    top: 423,
  },
  container: {
    top: 23,
  },
  frame: {
    top: 123,
  },
  frameView: {
    top: 223,
  },
  wrapper1: {
    top: 323,
  },
  rectangleParent: {
    top: 92,
    height: 480,
    width: 333,
    left: 30,
    position: "absolute",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
    position: "absolute",
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  orders: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default Orders;
