import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import Group15 from "../assets/group-15.svg";
import InputFields from "../components/InputFields";
import Vector36 from "../assets/vector-36.svg";
import PrimaryButton from "../components/PrimaryButton";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const PersonalInformation = () => {
  return (
    <View style={styles.personalInformation}>
      <View style={styles.personalInformationChild} />
      <Text style={styles.text}>Անձնական տվյալներ</Text>
      <Group15 style={styles.personalInformationItem} width={40} height={40} />
      <View style={styles.iphoneIndicator}>
        <View style={[styles.line, styles.linePosition]} />
      </View>
      <InputFields
        placeholder
        state="Default"
        inputFieldsTop={337}
        inputFieldsLeft="50%"
        inputFieldsMarginLeft={-166.5}
        inputFieldsWidth={333}
        placeholder1="Էլ․ հասցե"
        showPlaceholder
        placeholder2="Էլ․ հասցե"
        placeholderFontWeight="unset"
      />
      <View style={[styles.inputFieldsParent, styles.linePosition]}>
        <InputFields
          placeholder
          state="Default"
          inputFieldsTop={0}
          inputFieldsLeft="50%"
          inputFieldsMarginLeft={-166.5}
          inputFieldsWidth={333}
          placeholder1="Անուն"
          showPlaceholder
          placeholder2="Անուն"
          placeholderFontWeight="unset"
        />
        <InputFields
          placeholder
          state="Default"
          inputFieldsTop={94}
          inputFieldsLeft="50%"
          inputFieldsMarginLeft={-166.5}
          inputFieldsWidth={333}
          placeholder1="Ազգանուն"
          showPlaceholder
          placeholder2="Ազգանուն"
          placeholderFontWeight="unset"
        />
        <InputFields
          placeholder
          state="Default"
          inputFieldsTop={282}
          inputFieldsLeft="50%"
          inputFieldsMarginLeft={-166.5}
          inputFieldsWidth={333}
          placeholder1="Հեռախոսահամար"
          showPlaceholder
          placeholder2="       +374"
          placeholderFontWeight="unset"
        />
        <Image
          style={styles.groupChild}
          resizeMode="cover"
          source={require("../assets/group-795.png")}
        />
        <Vector36 style={styles.groupItem} height={50} />
        <PrimaryButton
          color="Cyan"
          size="default"
          state="Default"
          button="Պահպանել"
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  linePosition: {
    left: "50%",
    position: "absolute",
  },
  personalInformationChild: {
    top: -22,
    left: -17,
    borderRadius: Border.br_59xl,
    backgroundColor: Color.color2,
    width: 426,
    height: 158,
    position: "absolute",
  },
  text: {
    top: 32,
    left: 85,
    fontSize: FontSize.size_lg,
    lineHeight: 25,
    fontWeight: "500",
    fontFamily: FontFamily.montserratArm,
    color: Color.textColor,
    textAlign: "left",
    position: "absolute",
  },
  personalInformationItem: {
    top: 24,
    left: 30,
    position: "absolute",
  },
  line: {
    marginLeft: -67.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorSilver,
    width: 135,
    height: 5,
  },
  iphoneIndicator: {
    bottom: 1,
    left: 1,
    width: 393,
    height: 30,
    position: "absolute",
  },
  groupChild: {
    top: 324,
    left: 18,
    width: 24,
    height: 14,
    position: "absolute",
  },
  groupItem: {
    top: 306,
    left: 102,
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  inputFieldsParent: {
    marginLeft: -166.5,
    top: 149,
    width: 333,
    height: 436,
  },
  personalInformation: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.bgColor,
    flex: 1,
    width: "100%",
    height: 907,
    overflow: "hidden",
  },
});

export default PersonalInformation;
