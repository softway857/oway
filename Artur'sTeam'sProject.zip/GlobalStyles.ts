/* fonts */
export const FontFamily = {
  montserratArm: "Montserrat arm",
  compassIcons: "compass-icons",
  interMedium: "Inter-Medium",
  interSemiBold: "Inter-SemiBold",
  arial: "Arial",
};
/* font sizes */
export const FontSize = {
  size_xs: 12,
  size_sm: 14,
  size_lg: 18,
  size_base: 16,
  size_mini_4: 14,
  size_xl: 20,
  size_base_7: 16,
  size_3xs: 10,
  size_smi_9: 13,
};
/* Colors */
export const Color = {
  bgColor: "#fbfbfb",
  colorGray_100: "#8e8e8e",
  colorGray_200: "#848484",
  textColor: "#1e293b",
  colorGray_300: "rgba(30, 41, 59, 0.88)",
  color2: "#1da99d",
  themeBackground: "#fff",
  colorDimgray_100: "#646464",
  darkMedium: "#4f4f4f",
  strokeColor: "#d0d5dd",
  secondaryText: "#64748b",
  colorSilver: "#b9c0c9",
  colorDarkgray: "rgba(161, 161, 161, 0.61)",
  colorGainsboro: "#e2e2e2",
  colorBlack: "#000",
  colorDarkslateblue: "#1d5da9",
  color1: "#ffa11d",
  colorsCardBG: "#f6f7f8",
  greyLight: "#f5f5f5",
  colorDarkcyan: "#089387",
};
/* Style Variables */
export const StyleVariable = {
  spacing6: 24,
  spacing11: 44,
  spacing05: 2,
  borderRadiusFull: 9999,
  spacing5: 20,
};
/* Gaps */
export const Gap = {
  gap_xs: 4,
  gap_sm: 6,
  gap_md: 15,
  gap_lg: 16,
  gap_xl: 20,
};
/* Paddings */
export const Padding = {
  p_base: 16,
  p_mini: 15,
  p_8xs: 5,
  p_6xs: 7,
  p_11xs: 2,
  p_31xl: 50,
  p_sm: 14,
  p_7xs: 6,
  p_9xs: 4,
  p_28xl: 47,
  p_lg: 18,
  p_5xs: 8,
};
/* border radiuses */
export const Border = {
  br_21xl: 40,
  br_6xs: 7,
  br_5xs: 8,
  br_9xs: 4,
  br_81xl: 100,
  br_59xl: 78,
  br_8xs: 5,
  br_60xl: 79,
  br_xl: 20,
  br_9980xl: 9999,
  br_51xl_4: 70,
  br_lgi: 19,
};
