const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";

import Overweight from "./screens/Overweight";
import ShippingCalculator from "./screens/ShippingCalculator";
import Settings2 from "./screens/Settings2";
import DeliveriesAccepted from "./screens/DeliveriesAccepted";
import InArmenia from "./screens/InArmenia";
import Group from "./screens/Group";
import PersonalInformation from "./screens/PersonalInformation";
import Registration from "./screens/Registration";
import Empty from "./screens/Empty";
import Orders from "./screens/Orders";
import More from "./screens/More";
import Laungages from "./screens/Laungages";
import IPhone1415Pro from "./screens/IPhone1415Pro";
import Notification1 from "./screens/Notification1";
import ForgotPassword from "./screens/ForgotPassword";
import DeleteAccount from "./screens/DeleteAccount";
import Store from "./screens/Store";
import MainPage from "./screens/MainPage";
import AddOrder1 from "./screens/AddOrder1";
import DeliveriesAccepted1 from "./screens/DeliveriesAccepted1";
import ContactUs from "./screens/ContactUs";
import ChangePass from "./screens/ChangePass";
import Login from "./screens/Login";
import Seetings from "./screens/Seetings";
import AddOrder from "./screens/AddOrder";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="Overweight"
              component={Overweight}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ShippingCalculator"
              component={ShippingCalculator}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Settings"
              component={Settings2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="DeliveriesAccepted"
              component={DeliveriesAccepted}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="InArmenia"
              component={InArmenia}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Group"
              component={Group}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="PersonalInformation"
              component={PersonalInformation}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Registration"
              component={Registration}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Empty"
              component={Empty}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Orders"
              component={Orders}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="More"
              component={More}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Laungages"
              component={Laungages}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro"
              component={IPhone1415Pro}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Notification1"
              component={Notification1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ForgotPassword"
              component={ForgotPassword}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="DeleteAccount"
              component={DeleteAccount}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Store"
              component={Store}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="MainPage"
              component={MainPage}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="AddOrder1"
              component={AddOrder1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="DeliveriesAccepted1"
              component={DeliveriesAccepted1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ContactUs"
              component={ContactUs}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ChangePass"
              component={ChangePass}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Login"
              component={Login}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Seetings"
              component={Seetings}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="AddOrder"
              component={AddOrder}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
